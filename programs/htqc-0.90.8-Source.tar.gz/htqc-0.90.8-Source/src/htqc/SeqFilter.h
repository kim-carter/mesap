/*
 * File:   SeqFilter.h
 * Author: yangxi
 *
 * Created on March 15, 2013, 2:44 PM
 */

#ifndef HTQC_SEQFILTER_H
#define	HTQC_SEQFILTER_H

#include "htio1/FastqSeq.h"
#include "htio1/HeaderUtil.h"
#include "htqc/Common.h"
#include <set>

namespace htqc
{

class SeqFilter
{
public:
    virtual ~SeqFilter();
    virtual bool check(const htio::FastqSeq& seq) = 0;
};

class SeqFilterLength : public SeqFilter
{
public:
    SeqFilterLength(size_t cut_len, htio::QualityEncode encode, bool mask);
    virtual ~SeqFilterLength();
    virtual bool check(const htio::FastqSeq& seq);

    htio::QualityEncode encode;
    size_t cut_len;
    bool mask;
};

class SeqFilterQuality : public SeqFilter
{
public:
    SeqFilterQuality(int cut_qual, htio::QualityEncode encode, bool mask);
    virtual ~SeqFilterQuality();
    virtual bool check(const htio::FastqSeq& seq);

    int cut_qual;
    htio::QualityEncode encode;
    bool mask;
};

typedef std::map<int, long> RejTileMap;
typedef std::pair<int, long>RejTileKV;

class SeqFilterTile : public SeqFilter
{
public:
    SeqFilterTile(htio::HeaderFormat h_format, bool with_sra);
    virtual ~SeqFilterTile();
    virtual bool check(const htio::FastqSeq& seq);

    RejTileMap rej_tiles;
    htio::HeaderParser h_parser;
};



} // namespace htqc

#endif	/* HTQC_SEQFILTER_H */

