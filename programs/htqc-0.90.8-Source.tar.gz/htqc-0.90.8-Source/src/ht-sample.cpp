//     HTQC - a high-throughput sequencing quality control toolkit
//
//     This program is free software: you can redistribute it and/or modify
//     it under the terms of the GNU General Public License as published by
//     the Free Software Foundation, either version 3 of the License, or
//     (at your option) any later version.
//
//     This program is distributed in the hope that it will be useful,
//     but WITHOUT ANY WARRANTY; without even the implied warranty of
//     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//     GNU General Public License for more details.
//
//     You should have received a copy of the GNU General Public License
//     along with this program.  If not, see <http://www.gnu.org/licenses/>.

#define USE_prefix_out
#define USE_single_paired
#include "htio1/FastqIO.h"
#include "htio1/FastqSeq.h"
#include "htqc/Options.h"
#include "boost/random/mersenne_twister.hpp"
#include "boost/random/uniform_real_distribution.hpp"
using namespace std;
using namespace htqc;
using namespace htio;

double OPT_rate;

boost::random::mt19937 prng;

void parse_options(int argc, char** argv)
{
    opt::options_description group_main("Options:");
    group_main.add_options()
    OPT_files_in_ENTRY
    OPT_prefix_out_ENTRY
    OPT_single_ENTRY
    OPT_paired_ENTRY
        ("rate,r", opt::value<double>(&OPT_rate), "1/rate of reads will be picked.");

    opt::options_description group_misc("Misc options:");
    group_misc.add_options()
    OPT_gzip_ENTRY
    OPT_quiet_ENTRY
    OPT_help_ENTRY
    OPT_version_ENTRY;
    group_main.add(group_misc);

    opt::variables_map var_map;
    opt::store(opt::parse_command_line(argc, argv, group_main), var_map);
    opt::notify(var_map);

    //
    // show help
    //
    if (OPT_help)
    {
        cout << endl
            << argv[0] << " - randomly pick some reads"
            << endl << endl
            << group_main;
        exit(EXIT_SUCCESS);
    }

    if (OPT_version) show_version_and_exit();

    //
    // validate options
    //
    check_single_paired();

    if (OPT_prefix_out.length() == 0)
    {
        cerr << "output not specified" << endl;
        exit(EXIT_FAILURE);
    }
    tidy_prefix_out(OPT_prefix_out);

    if (OPT_rate == 0)
    {
        cerr << "sampling rate not specified" << endl;
        exit(EXIT_FAILURE);
    }
    if (OPT_rate <= 1)
    {
        cerr << "invalid sampling rate: " << OPT_rate << ", must larger than 1" << endl;
        exit(EXIT_FAILURE);
    }
}

void log_header()
{
    show_single_paired();
    show_files_in();
    show_prefix_out();
    cout << "#fraction picked: 1/" << OPT_rate << endl;
}

void filter_se()
{
    boost::random::uniform_real_distribution<double> dist(0, OPT_rate);

    string file_out = string(OPT_prefix_out) + ".fastq";
    if (OPT_gzip) file_out += ".gz";

    // check if output file is same with any input file
    for (size_t i = 0; i < OPT_files_in.size(); i++)
    {
        if (OPT_files_in[i] == file_out)
        {
            cerr << "output file will overwrite input file: " << file_out << endl;
            exit(EXIT_FAILURE);
        }
    }

    FastqIO OUT(file_out, HTIO_WRITE, OPT_gzip);

    FastqSeq curr_seq;

    int64_t n_accept = 0;
    int64_t n_seq = 0;

    for (size_t i = 0; i < OPT_files_in.size(); i++)
    {
        FastqIO IN(OPT_files_in[i], HTIO_READ, OPT_gzip);

        while (IN.next_seq(curr_seq))
        {
            n_seq++;

            if (dist(prng) < 1)
            {
                OUT.write_seq(curr_seq);
                n_accept++;
            }

            if (!OPT_quiet && (n_seq % LOG_BLOCK == 0))
                cout << "\t" << n_seq << " reads, " << n_accept << " accept" << endl;
        }
    }
    if (!OPT_quiet)
        cout << "\t" << n_seq << " reads, " << n_accept << " accept" << endl;
}

void filter_pe()
{
    boost::random::uniform_real_distribution<double> dist(0, OPT_rate);

    vector<string> files_in_a;
    vector<string> files_in_b;
    separate_paired_files(OPT_files_in, files_in_a, files_in_b);

    string file_out_a = string(OPT_prefix_out) + "_1.fastq";
    string file_out_b = string(OPT_prefix_out) + "_2.fastq";
    if (OPT_gzip)
    {
        file_out_a += ".gz";
        file_out_b += ".gz";
    }

    // check if output file is same with any input file
    for (size_t i = 0; i < files_in_a.size(); i++)
    {
        if (files_in_a[i] == file_out_a || files_in_b[i] == file_out_a)
        {
            cerr << "output file will overwrite input file: " << file_out_a << endl;
            exit(EXIT_FAILURE);
        }
        if (files_in_a[i] == file_out_b || files_in_b[i] == file_out_b)
        {
            cerr << "output file will overwrite input file: " << file_out_b << endl;
            exit(EXIT_FAILURE);
        }
    }

    FastqIO OUT_A(file_out_a, HTIO_WRITE, OPT_gzip);
    FastqIO OUT_B(file_out_b, HTIO_WRITE, OPT_gzip);

    FastqSeq curr_seq_a;
    FastqSeq curr_seq_b;

    int64_t n_accept = 0;
    int64_t n_pair = 0;

    for (size_t i = 0; i < files_in_a.size(); i++)
    {
        FastqIO IN_A(files_in_a[i], HTIO_READ, OPT_gzip);
        FastqIO IN_B(files_in_b[i], HTIO_READ, OPT_gzip);
        while (1)
        {
            bool re_a = IN_A.next_seq(curr_seq_a);
            bool re_b = IN_B.next_seq(curr_seq_b);

            if (re_a)
            {
                if (re_b)
                {
                    n_pair++;

                    if (dist(prng) < 1)
                    {
                        OUT_A.write_seq(curr_seq_a);
                        OUT_B.write_seq(curr_seq_b);
                        n_accept++;
                    }
                }
                else
                {
                    cerr << "input file B finished, but input file A not" << endl
                        << files_in_a[i] << " and " << files_in_b[i] << endl;
                    exit(EXIT_FAILURE);
                }
            }
            else
            {
                if (re_b)
                {
                    cerr << "input file A finished, but input file B not" << endl
                        << files_in_a[i] << " and " << files_in_b[i] << endl;
                    exit(EXIT_FAILURE);
                }
                else
                    break;
            }

            if (!OPT_quiet && (n_pair % LOG_BLOCK == 0))
                cout << "\t" << n_pair << " pairs, " << n_accept << " picked" << endl;
        }
    }
    cout << "\t" << n_pair << " pairs, " << n_accept << " picked" << endl;
}

int main(int argc, char **argv)
{
    parse_options(argc, argv);

    if (!OPT_quiet) log_header();

    //
    // traverse input
    //
    if (OPT_paired)
    {
        filter_pe();
    }
    else if (OPT_single)
    {
        filter_se();
    }
    else
    {
        cerr << "neither single nor paired" << endl;
        exit(EXIT_FAILURE);
    }

    if (!OPT_quiet)
        cout << "done" << endl;
}
