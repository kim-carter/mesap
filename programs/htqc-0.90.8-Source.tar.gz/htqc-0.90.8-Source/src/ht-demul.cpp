#include "htio1/FastqIO.h"
#include "htio1/FastqSeq.h"
#include "htio1/PlainFileHandle.h"
#include "htio1/HeaderUtil.h"

#define USE_header_format
#define USE_single_paired
#include "htqc/Options.h"

#include <boost/filesystem.hpp>

using namespace std;
using namespace htqc;
namespace fs = boost::filesystem;

string OPT_dir_out;
string OPT_file_barcode;
int OPT_mismatch;

void parse_options(int argc, char** argv)
{
    opt::options_description opt_main("Options");
    opt_main.add_options()
    OPT_files_in_ENTRY
        ("out,o", opt::value<string>(&OPT_dir_out), "output directory")
        ("barcode", opt::value<string>(&OPT_file_barcode), "tab-delimited file containing project, sample and barcode. Output will be written to output_dir/project/sample_[12].fastq")
        ("mismatch", opt::value<int>(&OPT_mismatch)->default_value(0), "allow specified number of mismatches in barcode")
        OPT_single_ENTRY
        OPT_paired_ENTRY;

    opt::options_description opt_misc("Misc options");
    opt_misc.add_options()
    OPT_header_format_ENTRY
    OPT_header_sra_ENTRY
    OPT_gzip_ENTRY
    OPT_quiet_ENTRY
    OPT_help_ENTRY
    OPT_version_ENTRY;

    opt_main.add(opt_misc);

    opt::variables_map var_map;
    opt::store(opt::parse_command_line(argc, argv, opt_main), var_map);
    opt::notify(var_map);

    // show help
    if (OPT_help)
    {
        cout << endl
            << argv[0] << " - demultiplex reads by barcode"
            << endl << endl
            << opt_main;
        exit(EXIT_SUCCESS);
    }

    if (OPT_version) show_version_and_exit();

    //
    // guess header format
    //
    if (OPT_header_format == htio::HTIO_HEADER_AUTO)
    {
        if (!OPT_quiet) cout << "guess header format from front " << NUM_GUESS << " sequences of file " << OPT_files_in[0] << endl;
        htio::FastqIO fh(OPT_files_in[0], htio::HTIO_READ, OPT_gzip);
        htio::guess_header_format(fh, NUM_GUESS, OPT_header_format, OPT_header_sra);
        if (OPT_header_format == htio::HTIO_HEADER_UNKNOWN || OPT_header_format == htio::HTIO_HEADER_AUTO)
        {
            cerr << "failed to guess header format from input file " << OPT_files_in[0] << endl;
            exit(EXIT_FAILURE);
        }
        if (!OPT_quiet)
        {
            cout << "header format is " << htio::cast<string>(OPT_header_format);
            if (OPT_header_sra) cout << ", with SRA" << endl;
            else cout << ", without SRA" << endl;
        }
    }

    //
    // validate options
    //
    check_single_paired();
    if (!OPT_dir_out.length())
    {
        cerr << "output directory not specified" << endl;
        exit(EXIT_FAILURE);
    }

    if (OPT_header_format != htio::HTIO_HEADER_1_8)
    {
        cerr << "only CASAVA 1.8 headers can be used for demultiplex" << endl
            << "your header format: " << htio::cast<string>(OPT_header_format) << endl;
        exit(EXIT_FAILURE);
    }
}

void log_header()
{
    show_single_paired();
    show_files_in();
    cout << "# output dir: " << OPT_dir_out << endl;
    cout << "# barcode file: " << OPT_file_barcode << endl;
    cout << "# allow mismatch: " << OPT_mismatch << endl;
    show_header_format();
}

void read_barcode(map<string, pair<string, string> > & barcodes)
{
    if (!OPT_quiet)
        cout << "read barcode file" << endl;
    barcodes.clear();

    htio::PlainFileHandle IN(OPT_file_barcode.c_str(), "r");
    string buffer;

    while (IN.read_line(buffer))
    {
        size_t tab1 = buffer.find_first_of('\t');
        size_t tab2 = buffer.find_first_of('\t', tab1 + 1);
        string proj(buffer.substr(0, tab1));
        string sample(buffer.substr(tab1 + 1, tab2 - tab1 - 1));
        string barcode(buffer.substr(tab2 + 1));

        if (!OPT_quiet)
            cout << "  " << proj << ": " << sample << ", " << barcode << endl;

        if (!barcodes.insert(make_pair(barcode, make_pair(proj, sample))).second)
        {
            cerr << "duplicate barcode: " << barcode << endl;
            exit(EXIT_FAILURE);
        }
    }
}

void gen_output_dir(const map<string, pair<string, string> > & barcodes)
{
    if (!OPT_quiet) cout << "create output directories" << endl;
    fs::path p_out(OPT_dir_out);

    fs::create_directory(p_out);

    set<string> projs;
    for (map<string, pair<string, string> >::const_iterator it = barcodes.begin(); it != barcodes.end(); it++)
    {
        projs.insert(it->second.first);
    }

    for (set<string>::const_iterator it = projs.begin(); it != projs.end(); it++)
    {
        fs::path p_out_proj(p_out / fs::path(*it));
        if (fs::is_directory(p_out_proj))
        {
            if (!OPT_quiet) cout << "  remove existing dir: " << p_out_proj.string() << endl;
            fs::remove_all(p_out_proj);
        }
        if (!OPT_quiet) cout << "  create output dir: " << p_out_proj.string() << endl;
        fs::create_directory(p_out_proj);
    }
}

bool check_barcode(const map<string, pair<string, string> > & barcodes,
                   const string& barcode,
                   string& proj,
                   string& sample)
{
    map<string, pair<string, string> >::const_iterator it = barcodes.find(barcode);

    if (it != barcodes.end())
    {
        proj = it->second.first;
        sample = it->second.second;
        return true;
    }
    else if (OPT_mismatch)
    {
        for (it = barcodes.begin(); it != barcodes.end(); it++)
        {
            const string& ref_barcode = it->first;
            if (ref_barcode.length() != barcode.length()) continue;
            size_t diff = 0;
            for (size_t i = 0; i < ref_barcode.length(); i++)
            {
                if (ref_barcode[i] != barcode[i]) diff++;
            }

            if (diff <= OPT_mismatch)
            {
                proj = it->second.first;
                sample = it->second.second;
                return true;
            }
        }
        return false;
    }
    else
    {
        return false;
    }
}

void demul_se(const map<string, pair<string, string> > & barcodes)
{
    htio::FastqSeq curr_seq;
    htio::HeaderParser parser(OPT_header_format, OPT_header_sra);
    string proj;
    string sample;

    int64_t n_accept = 0;
    int64_t n_seq = 0;

    fs::path file_fail;
    if (OPT_gzip)
        file_fail = fs::path(OPT_dir_out) / fs::path("demul_failed.fastq.gz");
    else
        file_fail = fs::path(OPT_dir_out) / fs::path("demul_failed.fastq");

    htio::FastqIO FAIL(file_fail.string(), htio::HTIO_WRITE, OPT_gzip);

    for (size_t file_i = 0; file_i < OPT_files_in.size(); file_i++)
    {
        htio::FastqIO IN(OPT_files_in[file_i], htio::HTIO_READ, OPT_gzip);

        while (IN.next_seq(curr_seq))
        {
            parser.parse(curr_seq.id, curr_seq.desc);

            if (check_barcode(barcodes, parser.barcode, proj, sample))
            {
                fs::path file_out;
                if (OPT_gzip)
                    file_out = fs::path(OPT_dir_out) / fs::path(proj) / fs::path(sample + ".fastq.gz");
                else
                    file_out = fs::path(OPT_dir_out) / fs::path(proj) / fs::path(sample + ".fastq");

                htio::FastqIO OUT(file_out.string(), htio::HTIO_APPEND, OPT_gzip);
                OUT.write_seq(curr_seq);
                n_accept++;
            }
            else
            {
                FAIL.write_seq(curr_seq);
            }

            n_seq++;
            if (!OPT_quiet && n_accept % LOG_BLOCK == 0)
                cout << "  " << n_seq << " sequences, " << n_accept << " has barcode" << endl;
        }
    }

    if (!OPT_quiet)
        cout << "  " << n_seq << " sequences, " << n_accept << " has barcode" << endl;
}

void demul_pe(const map<string, pair<string, string> > & barcodes)
{
    htio::FastqSeq curr1;
    htio::FastqSeq curr2;
    htio::HeaderParser parser1(OPT_header_format, OPT_header_sra);
    htio::HeaderParser parser2(OPT_header_format, OPT_header_sra);

    string proj;
    string sample;

    int64_t n_accept = 0;
    int64_t n_seq = 0;

    if (OPT_files_in.size() % 2)
    {
        cerr << "odd number of input file: " << OPT_files_in.size() << endl;
        exit(EXIT_FAILURE);
    }
    size_t hf_sz = OPT_files_in.size() / 2;

    fs::path file_fail1;
    fs::path file_fail2;

    if (OPT_gzip)
    {
        file_fail1 = fs::path(OPT_dir_out) / fs::path("demul_failed_1.fastq.gz");
        file_fail2 = fs::path(OPT_dir_out) / fs::path("demul_failed_2.fastq.gz");
    }
    else
    {
        file_fail1 = fs::path(OPT_dir_out) / fs::path("demul_failed_1.fastq");
        file_fail2 = fs::path(OPT_dir_out) / fs::path("demul_failed_2.fastq");
    }

    htio::FastqIO FAIL1(file_fail1.string(), htio::HTIO_WRITE, OPT_gzip);
    htio::FastqIO FAIL2(file_fail2.string(), htio::HTIO_WRITE, OPT_gzip);

    for (size_t file_i = 0; file_i < hf_sz; file_i++)
    {
        htio::FastqIO IN1(OPT_files_in[file_i], htio::HTIO_READ, OPT_gzip);
        htio::FastqIO IN2(OPT_files_in[file_i + hf_sz], htio::HTIO_READ, OPT_gzip);

        while (1)
        {
            bool re1 = IN1.next_seq(curr1);
            bool re2 = IN2.next_seq(curr2);

            if (re1)
            {
                if (re2);
                else
                {
                    cerr << "input file a finished, but input file b not" << endl;
                    exit(EXIT_FAILURE);
                }
            }
            else
            {
                if (re2)
                {
                    cerr << "input file b finished, but input file a not" << endl;
                    exit(EXIT_FAILURE);
                }
                else
                    break;
            }

            if (curr1.id != curr2.id)
            {
                cerr << "paired-end has conflict ID:" << endl
                    << curr1.id << endl << curr2.id << endl;
                exit(EXIT_FAILURE);
            }

            parser1.parse(curr1.id, curr1.desc);
            parser2.parse(curr2.id, curr2.desc);

            if (parser1.barcode != parser2.barcode)
            {
                cerr << "paired-end has conflict barcodes: " << endl
                    << parser1.barcode << endl
                    << parser2.barcode << endl;
                exit(EXIT_FAILURE);
            }

            if (check_barcode(barcodes, parser1.barcode, proj, sample))
            {
                fs::path file_out_1;
                fs::path file_out_2;
                
                if (OPT_gzip)
                {
                    file_out_1 = fs::path(OPT_dir_out) / fs::path(proj) / fs::path(sample + "_1.fastq.gz");
                    file_out_2 = fs::path(OPT_dir_out) / fs::path(proj) / fs::path(sample + "_2.fastq.gz");
                }
                else
                {
                    file_out_1 = fs::path(OPT_dir_out) / fs::path(proj) / fs::path(sample + "_1.fastq");
                    file_out_2 = fs::path(OPT_dir_out) / fs::path(proj) / fs::path(sample + "_2.fastq");
                }

                htio::FastqIO O1(file_out_1.string(), htio::HTIO_APPEND, OPT_gzip);
                htio::FastqIO O2(file_out_2.string(), htio::HTIO_APPEND, OPT_gzip);
                O1.write_seq(curr1);
                O2.write_seq(curr2);
                n_accept++;
            }
            else
            {
                FAIL1.write_seq(curr1);
                FAIL2.write_seq(curr2);
            }

            n_seq++;
            if (!OPT_quiet && n_accept % LOG_BLOCK == 0)
                cout << "  " << n_seq << " paired-ends, " << n_accept << " has barcode" << endl;
        }
    }

    if (!OPT_quiet)
        cout << "  " << n_seq << " paired-ends, " << n_accept << " has barcode" << endl;
}

int main(int argc, char** argv)
{
    parse_options(argc, argv);

    if (!OPT_quiet) log_header();

    // read barcode map
    map<string, pair<string, string> > barcodes;
    read_barcode(barcodes);

    // generate output directories
    gen_output_dir(barcodes);

    // demultiplex
    if (OPT_paired)
        demul_pe(barcodes);
    else if (OPT_single)
        demul_se(barcodes);
    else
    {
        cerr << "neither single nor paired" << endl;
        exit(EXIT_FAILURE);
    }

    if (!OPT_quiet)
        cout << "done" << endl;
}