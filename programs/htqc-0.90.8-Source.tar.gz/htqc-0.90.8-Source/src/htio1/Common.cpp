#include "htio1/Common.h"
#include "htio1/config.h"

#include <sstream>

using namespace std;

namespace htio
{

const char NT_COMPLEMENT[128] = {
                                 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                                 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                                 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                                 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                                 0, 'T', 0, 'G', 0, 0, 0, 'C', 0, 0, 0, 0, 0, 0, 'N', 0,
                                 0, 0, 0, 0, 'A', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
                                 0, 't', 0, 'g', 0, 0, 0, 'c', 0, 0, 0, 0, 0, 0, 'n', 0,
                                 0, 0, 0, 0, 'a', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
};

void revcom(const std::string& in, std::string& out)
{
    out.clear();
    out.reserve(in.size());
    for (int i = in.size() - 1; i >= 0; i--)
    {
        char comp = NT_COMPLEMENT[uint8_t(in[i])];
        if (comp == 0)
            throw runtime_error("sequence contain invalid character:\n\"" + in + "\"");
        out.push_back(comp);
    }
}

template<>
std::string cast<std::string, QualityEncode>(QualityEncode arg)
{
    switch (arg)
    {
    case HTIO_ENCODE_UNKNOWN:
        return "unknown";
    case HTIO_ENCODE_SANGER:
        return "sanger";
    case HTIO_ENCODE_SOLEXA:
        return "solexa";
    case HTIO_ENCODE_ILLUMINA:
        return "illumina";
    case HTIO_ENCODE_CASAVA_1_8:
        return "casava1.8";
    case HTIO_ENCODE_AUTO:
        return "auto";
    default:
        return "INVALID";
    }
}

template<>
std::string cast<std::string, HeaderFormat>(HeaderFormat arg)
{
    switch (arg)
    {
    case HTIO_HEADER_UNKNOWN:
        return "unknown";
    case HTIO_HEADER_PRI_1_8:
        return "pri_casava1.8";
    case HTIO_HEADER_1_8:
        return "casava1.8";
    case HTIO_HEADER_AUTO:
        return "auto";
    default:
        return "INVALID";
    }
}

template<>
QualityEncode cast<QualityEncode, const std::string&>(const std::string& arg)
{
    if (arg == "auto")
        return HTIO_ENCODE_AUTO;
    else if (arg == "sanger")
        return HTIO_ENCODE_SANGER;
    else if (arg == "solexa")
        return HTIO_ENCODE_SOLEXA;
    else if (arg == "illumina")
        return HTIO_ENCODE_ILLUMINA;
    else if (arg == "casava1.8")
        return HTIO_ENCODE_CASAVA_1_8;
    else
        return HTIO_ENCODE_UNKNOWN;
}

template<>
HeaderFormat cast<HeaderFormat, const std::string&>(const std::string& arg)
{
    if (arg == "auto")
        return HTIO_HEADER_AUTO;
    else if (arg == "pri_casava1.8")
        return HTIO_HEADER_PRI_1_8;
    else if (arg == "casava1.8")
        return HTIO_HEADER_1_8;
    else
        return HTIO_HEADER_UNKNOWN;
}

std::string get_version_string()
{
    ostringstream result;
    result << HTIO_VERSION_MAJOR << "." << HTIO_VERSION_MINOR << "." << HTIO_VERSION_PATCH;
    return result.str();
}

} // namespace htio
