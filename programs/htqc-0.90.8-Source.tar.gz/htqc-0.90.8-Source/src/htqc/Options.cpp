//     HTQC - a high-throughput sequencing quality control toolkit
//
//     This program is free software: you can redistribute it and/or modify
//     it under the terms of the GNU General Public License as published by
//     the Free Software Foundation, either version 3 of the License, or
//     (at your option) any later version.
//
//     This program is distributed in the hope that it will be useful,
//     but WITHOUT ANY WARRANTY; without even the implied warranty of
//     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//     GNU General Public License for more details.
//
//     You should have received a copy of the GNU General Public License
//     along with this program.  If not, see <http://www.gnu.org/licenses/>.

#define USE_file_out
#define USE_prefix_out
#define USE_single_paired
#define USE_encode
#define USE_header_format
#define USE_mask
#include "htqc/Options.h"

using namespace std;
using namespace htio;

namespace htio
{

void validate(boost::any& v, const vector<string>& values, QualityEncode* target_type, int)
{
    opt::validators::check_first_occurrence(v);
    const string& value = opt::get_single_string(values);
    v = boost::any(cast<QualityEncode, const std::string&>(value));
}

void validate(boost::any& v, const vector<string>& values, HeaderFormat* target_type, int)
{
    opt::validators::check_first_occurrence(v);
    const string& value = opt::validators::get_single_string(values);
    v = boost::any(cast<QualityEncode, const std::string&>(value));
}

} // namespace htio

namespace htqc
{

bool OPT_help;
OPT_files_in_TYPE OPT_files_in;
std::string OPT_file_out;
std::string OPT_prefix_out;
htio::QualityEncode OPT_encode;
htio::HeaderFormat OPT_header_format;
bool OPT_header_sra;
bool OPT_mask;
bool OPT_version;
bool OPT_quiet;
bool OPT_single;
bool OPT_paired;
bool OPT_gzip;

void show_files_in()
{
    cout << "# input files:" << endl;
    if (OPT_single)
    {
        for (size_t i = 0; i < OPT_files_in.size(); i++)
            cout << "#  " << OPT_files_in[i] << endl;
    }
    else if (OPT_paired)
    {
        if (OPT_files_in.size() % 2)
            throw runtime_error("odd number of input files");
        size_t hf_sz = OPT_files_in.size() / 2;
        for (size_t i = 0; i < hf_sz; i++)
            cout << "#  " << OPT_files_in[i] << " and " << OPT_files_in[i + hf_sz] << endl;
    }
}

void show_file_out()
{
    cout << "# output file: " << OPT_file_out << endl;
}

void show_prefix_out()
{
    cout << "# output prefix: " << OPT_prefix_out << endl;
}

void show_single_paired()
{
    if (OPT_single)
    {
        cout << "# single-end" << endl;
    }
    else if (OPT_paired)
    {
        cout << "# paired-end" << endl;
    }
    else
    {
        throw runtime_error("neither single-end nor paired-end");
    }
}

void show_encode()
{
    cout << "# quality encoding: " << encode_to_string(OPT_encode) << endl;
}

void show_header_format()
{
    cout << "# header format: " << header_format_to_string(OPT_header_format) << endl;
}

void show_mask()
{
    cout << "# quality has mask: " << bool_to_string(OPT_mask) << endl;
}

void check_single_paired()
{
    if (OPT_single)
    {
        if (OPT_paired)
        {
            cerr << "only one of --single and --paired can be chosen" << endl;
            exit(EXIT_FAILURE);
        }
    }
    else
    {
        if (!OPT_paired)
        {
            cerr << "--single or --paired?" << endl;
            exit(EXIT_FAILURE);
        }
    }
}

void tidy_prefix_out(std::string& prefix)
{
    remove_suffix(prefix, ".gz");
    remove_suffix(prefix, ".fq");
    remove_suffix(prefix, ".fastq");
}

void show_version_and_exit()
{
    cout << htio::get_version_string() << endl;
    exit(EXIT_SUCCESS);
}

void separate_paired_files(const std::vector<std::string>& in, std::vector<std::string>& names_a, std::vector<std::string>& names_b)
{
    size_t size = in.size();

    if (size % 2)
    {
        cerr << "odd number of files for paired-end mode: " << size << endl;
        for (int i = 0; i < size; i++)
        {
            cerr << "  " << in[i] << endl;
        }
        exit(EXIT_FAILURE);
    }

    int half = size / 2;

    for (int i = 0; i < half; i++)
        names_a.push_back(in[i]);

    for (int i = half; i < size; i++)
        names_b.push_back(in[i]);
}

void remove_suffix(std::string& name, const std::string& suffix)
{
    size_t suffix_pos = name.rfind(suffix);
    if (suffix_pos != string::npos)
        name.erase(suffix_pos);
}

} // namespace htqc
