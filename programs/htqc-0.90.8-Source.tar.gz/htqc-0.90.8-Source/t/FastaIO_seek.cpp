#include "htio1/FastaIO.h"
#include "htio1/SimpleSeq.h"

using namespace std;
using namespace htio;

int main(int argc, char** argv)
{
    if (argc != 2)
    {
        cerr << "usage: ./FastaIO fasta_file" << endl;
        exit(EXIT_FAILURE);
    }

    FastaIO IN(argv[1], HTIO_READ);

    off_t first_pos = IN.tell();
    off_t last_pos = -1;

    SimpleSeq seq;
    while (1)
    {
        off_t curr_pos = IN.tell();
        if (!IN.next_seq(seq)) break;
        last_pos = curr_pos;

        cout << "offset before this seq: " << curr_pos << endl;
        cout << "ID     : \"" << seq.id << "\"" << endl;
        cout << "desc   : \"" << seq.desc << "\"" << endl;
        cout << "seq    : \"" << seq.seq << "\"" << endl;
        cout << "offset after this seq: " << IN.tell() << endl;
        cout << endl;
    }


    cout << "#\n# return to first sequence at " << first_pos << endl
        << "#" << endl;
    IN.seek(first_pos, 0);
    IN.next_seq(seq);
    cout << "ID     : \"" << seq.id << "\"" << endl;
    cout << "desc   : \"" << seq.desc << "\"" << endl;
    cout << "seq    : \"" << seq.seq << "\"" << endl;
    cout << endl;

    cout << "#\n# go to last sequence at " << last_pos << endl
        << "#" << endl;
    IN.seek(last_pos, 0);
    IN.next_seq(seq);
    cout << "ID     : \"" << seq.id << "\"" << endl;
    cout << "desc   : \"" << seq.desc << "\"" << endl;
    cout << "seq    : \"" << seq.seq << "\"" << endl;
    cout << endl;
}

