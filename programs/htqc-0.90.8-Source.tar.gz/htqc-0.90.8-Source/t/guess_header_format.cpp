#include "htio1/HeaderUtil.h"
#include "htio1/FastqIO.h"
#include <iostream>
#include <cstdio>

using namespace std;
using namespace htio;

int main(int argc, char** argv)
{
    FastqIO IN(stdin, false);

    HeaderFormat format = HTIO_HEADER_AUTO;
    bool ncbi_flag = false;
    guess_header_format(IN, 10, format, ncbi_flag);
    cout << "format: " << cast<string>(format) << ", NCBI addition: " << ncbi_flag << endl;
}
