/*
 * File:   AsyncQueue.h
 * Author: yangxi
 *
 * Created on May 27, 2013, 2:50 PM
 */

#ifndef SCHIZO_ASYNCQUEUE_H
#define	SCHIZO_ASYNCQUEUE_H

#include "htqc/Common.h"
#include <boost/thread.hpp>
#include <queue>

namespace htqc
{

template <typename T>
class AsyncQueue
{
public:

    AsyncQueue() { }

    void push(const T& data)
    {
        boost::unique_lock<boost::mutex> lock(mutex);
        queue.push(data);
        if (waiting_threads > 0)
            cond.notify_one();
    }

    T pop()
    {
        boost::unique_lock<boost::mutex> lock(mutex);

        T re;

        if (queue.empty())
        {
            waiting_threads++;
            while (queue.empty())
            {
                cond.wait(lock);
            }
            waiting_threads--;
        }

        re = queue.front();
        queue.pop();
        return re;
    }

protected:
    size_t waiting_threads;
    boost::mutex mutex;
    boost::condition_variable cond;
    std::queue<T> queue;
private:
    AsyncQueue(const AsyncQueue& other);
    AsyncQueue& operator=(const AsyncQueue& other);
};

} // namespace schizo

#endif	/* SCHIZO_ASYNCQUEUE_H */

