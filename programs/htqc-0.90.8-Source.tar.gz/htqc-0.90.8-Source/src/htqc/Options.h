//     HTQC - a high-throughput sequencing quality control toolkit
//
//     This program is free software: you can redistribute it and/or modify
//     it under the terms of the GNU General Public License as published by
//     the Free Software Foundation, either version 3 of the License, or
//     (at your option) any later version.
//
//     This program is distributed in the hope that it will be useful,
//     but WITHOUT ANY WARRANTY; without even the implied warranty of
//     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//     GNU General Public License for more details.
//
//     You should have received a copy of the GNU General Public License
//     along with this program.  If not, see <http://www.gnu.org/licenses/>.

#ifndef HTQC_OPTIONS_H
#define	HTQC_OPTIONS_H

#include "htqc/Common.h"
#include <boost/program_options.hpp>

namespace opt = boost::program_options;

namespace htio
{

void validate(boost::any& v, const std::vector<std::string>& values, htio::QualityEncode* target_type, int);
void validate(boost::any& v, const std::vector<std::string>& values, htio::HeaderFormat* target_type, int);

} // namespace htio

namespace htqc
{

typedef std::vector<std::string> OPT_files_in_TYPE;
extern OPT_files_in_TYPE OPT_files_in;
void show_files_in();
#define OPT_files_in_ENTRY ("in,i", opt::value<OPT_files_in_TYPE> (&OPT_files_in)->multitoken(), "Input files.")

#ifdef USE_file_out
extern std::string OPT_file_out;
void show_file_out();
#define OPT_file_out_ENTRY ("out,o", opt::value<std::string> (&OPT_file_out), "Output file.")
#endif

#ifdef USE_prefix_out
extern std::string OPT_prefix_out;
void show_prefix_out();
#define OPT_prefix_out_ENTRY ("out,o", opt::value<std::string> (&OPT_prefix_out), "Prefix for output files.")
#endif

#ifdef USE_single_paired
extern bool OPT_single;
extern bool OPT_paired;
void show_single_paired();
#define OPT_single_ENTRY ("single-end,S", opt::bool_switch(&OPT_single), "Inputs are single-end.")
#define OPT_paired_ENTRY ("paired-end,P", opt::bool_switch(&OPT_paired), "Inputs are paired-end.")
#endif

#ifdef USE_encode
extern htio::QualityEncode OPT_encode;
void show_encode();
#define OPT_encode_ENTRY ("encode", opt::value<htio::QualityEncode> (&OPT_encode)->default_value(htio::HTIO_ENCODE_AUTO, "auto"), "Quality score encode.\n  sanger   : \t0 - 93 using ASCII 33 - 126\n  solexa   : \t-5 - 62 using ASCII 59 - 126\n  illumina : \t0 - 62 using ASCII 64 - 126\n  casava1.8: \t0 - 62 using ASCII 33 - 95; 0 1 not used; values >40 rarely used")
#endif

#ifdef USE_header_format
extern htio::HeaderFormat OPT_header_format;
extern bool OPT_header_sra;
void show_header_format();
#define OPT_header_format_ENTRY ("header-format", opt::value<htio::HeaderFormat> (&OPT_header_format)->default_value(htio::HTIO_HEADER_AUTO, "auto"), "FASTQ header format.\n  casava1.8: \tproduced by Illumina CASAVA version 1.8\n  pri_casava1.8: \tproduced by Illumina CASAVA version 1.7 or lower")
#define OPT_header_sra_ENTRY ("header-sra", opt::bool_switch(&OPT_header_sra)->default_value(false), "Whether FASTQ header has NCBI SRA addon.")
#endif

#ifdef USE_mask
extern bool OPT_mask;
void show_mask();
#define OPT_mask_ENTRY ("quality-mask", opt::bool_switch(&OPT_mask)->default_value(true), "treat quality score 2 as a mask.")
#endif

extern bool OPT_quiet;
#define OPT_quiet_ENTRY ("quiet,q", opt::bool_switch(&OPT_quiet), "Do not show trivial information.")

extern bool OPT_gzip;
#define OPT_gzip_ENTRY ("gzip,z", opt::bool_switch(&OPT_gzip), "Gzipped input and output.")

extern bool OPT_help;
#define OPT_help_ENTRY ("help,h", opt::bool_switch(&OPT_help), "Show help.")

extern bool OPT_version;
#define OPT_version_ENTRY ("version,v", opt::bool_switch(&OPT_version), "Show version.")

void check_single_paired();

void tidy_prefix_out(std::string& prefix);

void show_version_and_exit();

void separate_paired_files(const std::vector<std::string>& in, std::vector<std::string>& names_a, std::vector<std::string>& names_b);

void remove_suffix(std::string& name, const std::string& suffix);

} // namespace htqc

#endif	/* HTQC_OPTIONS_H */

