//     HTQC - a high-throughput sequencing quality control toolkit
//
//     This program is free software: you can redistribute it and/or modify
//     it under the terms of the GNU General Public License as published by
//     the Free Software Foundation, either version 3 of the License, or
//     (at your option) any later version.
//
//     This program is distributed in the hope that it will be useful,
//     but WITHOUT ANY WARRANTY; without even the implied warranty of
//     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//     GNU General Public License for more details.
//
//     You should have received a copy of the GNU General Public License
//     along with this program.  If not, see <http://www.gnu.org/licenses/>.

#include "htio1/FastqIO.h"
#include "htio1/FastqSeq.h"

#define USE_file_out
#define USE_encode
#define USE_single_paired
#include "htqc/Options.h"
#include "htio1/QualityUtil.h"

using namespace std;
using namespace htqc;
using namespace htio;

htio::QualityEncode OPT_encode_out;

void parse_options(int argc, char** argv)
{
    opt::options_description group_main("Options");
    group_main.add_options()
    OPT_files_in_ENTRY
    OPT_file_out_ENTRY
        ("out-encode,O", opt::value<htio::QualityEncode>(&OPT_encode_out)->default_value(htio::HTIO_ENCODE_UNKNOWN), "Output quality encode.");

    opt::options_description group_misc("Misc options:");
    group_misc.add_options()
    OPT_encode_ENTRY
    OPT_gzip_ENTRY
    OPT_quiet_ENTRY
    OPT_help_ENTRY
    OPT_version_ENTRY;
    group_main.add(group_misc);

    opt::variables_map var_map;
    opt::store(opt::parse_command_line(argc, argv, group_main), var_map);
    opt::notify(var_map);

    // we are always processing single-end
    OPT_single = true;

    //
    // show help
    //
    if (OPT_help)
    {
        cout << endl
            << argv[0] << " - remove bad bases from reads head or tail"
            << endl << endl
            << group_main;
        exit(EXIT_SUCCESS);
    }

    if (OPT_version) show_version_and_exit();

    //
    // validate options
    //
    if (OPT_file_out.length() == 0)
    {
        cerr << "output file not specified" << endl;
        exit(EXIT_FAILURE);
    }
    if (OPT_encode_out == HTIO_ENCODE_UNKNOWN)
    {
        cerr << "output encode not specified" << endl;
        exit(EXIT_FAILURE);
    }

    //
    // guess quality encoding
    //
    if (OPT_encode == HTIO_ENCODE_AUTO)
    {
        if (!OPT_quiet) cout << "guess encode from front " << NUM_GUESS << " sequences of file " << OPT_files_in[0] << endl;
        FastqIO fh(OPT_files_in[0], HTIO_READ, OPT_gzip);
        OPT_encode = guess_quality_encode(fh, NUM_GUESS);
        if (OPT_encode == HTIO_ENCODE_UNKNOWN || OPT_encode == HTIO_ENCODE_AUTO)
        {
            cerr << "failed to guess quality encode from input file " << OPT_files_in[0] << endl;
            exit(EXIT_FAILURE);
        }
        if (!OPT_quiet) cout << "encode: " << encode_to_string(OPT_encode) << endl;
    }
}

int main(int argc, char** argv)
{
    // parse arguments
    parse_options(argc, argv);

    // show parameters
    if (!OPT_quiet)
    {
        show_files_in();
        show_file_out();
        cout << "# input encoding : " << encode_to_string(OPT_encode) << endl;
        cout << "# output encoding: " << encode_to_string(OPT_encode_out) << endl;
    }

    // output
    if (OPT_gzip && OPT_file_out.rfind(".gz") == string::npos)
    {
        OPT_file_out += ".gz";
    }

    FastqIO OUT(OPT_file_out, HTIO_WRITE, OPT_gzip);

    //
    // traverse input
    //
    FastqSeq curr_seq;
    string curr_qual_to;
    size_t n = 0;

    for (size_t file_i = 0; file_i < OPT_files_in.size(); file_i++)
    {
        FastqIO IN(OPT_files_in[file_i], HTIO_READ, OPT_gzip);

        while (IN.next_seq(curr_seq))
        {
            n++;
            recode_quality(curr_seq.quality, curr_qual_to, OPT_encode, OPT_encode_out);
            curr_seq.quality = curr_qual_to;
            OUT.write_seq(curr_seq);

            if (n % LOG_BLOCK == 0)
                cout << "\t" << n << " reads" << endl;
        }
    }

    if (!OPT_quiet)
        cout << "done: " << n << " reads" << endl;
}
