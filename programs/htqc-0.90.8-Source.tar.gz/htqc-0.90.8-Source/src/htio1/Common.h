#ifndef HTIO_COMMON_H
#define	HTIO_COMMON_H

#include <stdint.h>
#include <cstdlib>

#include <string>
#include <vector>
#include <stdexcept>
#include <iostream>

namespace htio
{

typedef enum
{
    HTIO_ENCODE_AUTO = 0,
    HTIO_ENCODE_SANGER = 1, ///< 0 to 93 using ASCII 33 to 126
    HTIO_ENCODE_SOLEXA = 2, ///< -5 to 62 using ASCII 59 to 126
    HTIO_ENCODE_ILLUMINA = 3, ///< 0 to 62 using ASCII 64 to 126
    HTIO_ENCODE_CASAVA_1_8 = 4, ///< 2 to 40 using ASCII 35 to 73
    HTIO_ENCODE_UNKNOWN = 255
} QualityEncode;

typedef enum
{
    HTIO_HEADER_AUTO = 0,
    HTIO_HEADER_PRI_1_8 = 1, ///< header format prior to CASAVA 1.8
    HTIO_HEADER_1_8 = 2, ///< header format by CASAVA 1.8
    HTIO_HEADER_UNKNOWN = 255
} HeaderFormat;

typedef enum
{
    HTIO_READ,
    HTIO_WRITE,
    HTIO_APPEND
} IOMode;

///
/// maps [ATGCNatgcn] to [TACGNtacgn]
///
extern const char NT_COMPLEMENT[128];

/**
 * generate reverse complement sequence
 * @param in input sequence
 * @param out output sequence
 */
void revcom(const std::string& in, std::string& out);

template <typename TO_TYPE, typename FROM_TYPE>
TO_TYPE cast(FROM_TYPE arg);

template<>
std::string cast<std::string, QualityEncode>(QualityEncode arg);

template<>
std::string cast<std::string, HeaderFormat>(HeaderFormat arg);


template<>
QualityEncode cast<QualityEncode, const std::string&>(const std::string& arg);

template<>
HeaderFormat cast<HeaderFormat, const std::string&>(const std::string& arg);

/**
 * get the version of HTIO library
 * @return version string formatted in "MAJOR.MINOR.PATCH"
 */
std::string get_version_string();

} // namespace htio

#endif	/* HTIO_COMMON_H */

