#ifndef HTIO_ERROR_H
#define	HTIO_ERROR_H

#include "htio1/Common.h"

namespace htio
{

class InvalidQualityEncode : public std::invalid_argument
{
public:
    InvalidQualityEncode(QualityEncode encode);
    virtual ~InvalidQualityEncode() throw ();
};

class InvalidHeaderFormat : public std::invalid_argument
{
public:
    InvalidHeaderFormat(HeaderFormat format);
    virtual ~InvalidHeaderFormat() throw ();
};

class InvalidFileContent : public std::runtime_error
{
public:
    InvalidFileContent(const std::string& content, size_t offset);
    virtual ~InvalidFileContent() throw ();
};

} // namespace htio

#endif	/* HTIO_ERROR_H */

