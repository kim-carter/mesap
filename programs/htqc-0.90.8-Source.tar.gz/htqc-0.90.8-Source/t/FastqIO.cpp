#include "htio1/FastqIO.h"
#include "htio1/FastqSeq.h"
#include <stdio.h>

using namespace std;
using namespace htio;

int main(int argc, char** argv)
{
    if (argc != 1)
    {
        cerr << "usage: ./FastqIO <fastq_file" << endl;
        exit(EXIT_FAILURE);
    }

    FastqIO IN(stdin, false);

    FastqSeq seq;
    while (IN.next_seq(seq))
    {
        cout << "ID     : \"" << seq.id << "\"" << endl;
        cout << "desc   : \"" << seq.desc << "\"" << endl;
        cout << "seq    : \"" << seq.seq << "\"" << endl;
        cout << "quality: \"" << seq.quality << "\"" << endl;
        cout << endl;
    }
}
