/*
 * File:   FastaSeq.h
 * Author: yangxi
 *
 * Created on December 25, 2012, 3:15 PM
 */

#ifndef HTIO_SIMPLESEQ_H
#define	HTIO_SIMPLESEQ_H

#include <htio1/Common.h>

namespace htio
{

class SimpleSeq
{
public:
    /**
     * Create an empty sequence object
     */
    SimpleSeq();

    /**
     * create an sequence object with ID, description and sequence
     * @param id
     * @param desc
     * @param seq
     */
    SimpleSeq(const std::string& id, const std::string& desc, const std::string& seq);
    virtual ~SimpleSeq();

    /**
     * get sequence length
     * @return sequence length
     */
    inline size_t length() const
    {
        return seq.length();
    }
    /**
     * generate reverse complement sequence
     * @param result
     */
    void revcom(SimpleSeq& result) const;

    /**
     * get part of the sequence
     * @param result
     * @param start the start of sub sequence, 0 for the first base
     * @param length the length of sub sequence
     */
    void subseq(SimpleSeq& result, size_t start, size_t length = std::string::npos) const;

    std::string id;
    std::string desc;
    std::string seq;
private:

};

} // namespace htio

#endif	/* HTIO_SIMPLESEQ_H */

