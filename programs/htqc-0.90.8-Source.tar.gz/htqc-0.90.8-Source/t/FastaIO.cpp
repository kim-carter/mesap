#include "htio1/FastaIO.h"
#include "htio1/SimpleSeq.h"

#include <cstdio>

using namespace std;
using namespace htio;

int main(int argc, char** argv)
{
    if (argc != 1)
    {
        cerr << "usage: ./FastaIO <fasta_file" << endl;
        exit(EXIT_FAILURE);
    }

    FastaIO IN(stdin,false);

    SimpleSeq seq;
    while (IN.next_seq(seq))
    {
        cout << "ID     : \"" << seq.id << "\"" << endl;
        cout << "desc   : \"" << seq.desc << "\"" << endl;
        cout << "seq    : \"" << seq.seq << "\"" << endl;
        cout << endl;
    }
}

