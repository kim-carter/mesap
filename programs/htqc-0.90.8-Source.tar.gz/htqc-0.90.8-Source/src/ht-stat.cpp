//     HTQC - a high-throughput sequencing quality control toolkit
//
//     This program is free software: you can redistribute it and/or modify
//     it under the terms of the GNU General Public License as published by
//     the Free Software Foundation, either version 3 of the License, or
//     (at your option) any later version.
//
//     This program is distributed in the hope that it will be useful,
//     but WITHOUT ANY WARRANTY; without even the implied warranty of
//     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//     GNU General Public License for more details.
//
//     You should have received a copy of the GNU General Public License
//     along with this program.  If not, see <http://www.gnu.org/licenses/>.

#include <vector>
#include <map>
#include <string>
#include <iostream>
#include <fstream>
#include <sstream>
#include <stdexcept>
#include <algorithm>
#include <cmath>

#include <boost/filesystem.hpp>
#include <boost/ref.hpp>

#include <htio1/FastqIO.h>
#include <htio1/QualityUtil.h>
#include <htio1/HeaderUtil.h>

#include "htqc/AsyncQueue.h"
#include "htqc/BaseQualCounter.h"
#include "htqc/FastqStat.h"

#define USE_single_paired
#define USE_encode
#define USE_header_format
#define USE_mask
#include "htqc/Options.h"

namespace fs = boost::filesystem;

using namespace std;
using namespace htqc;
using namespace htio;

struct StatWorker;

//
// threads
//
vector<StatWorker*> workers;
vector<boost::thread*> threads;

// list of statistics, one for each thread
vector<FastqStat> stats_a;
vector<FastqStat> stats_b;

// list of reads, one for each thread
vector<FastqSeq> reads_a;
vector<FastqSeq> reads_b;

// send todo reads to worker thread
AsyncQueue<size_t> i_todo;

// return finished reads to controller
AsyncQueue<size_t> i_done;

//
// command-line arguments
//
int OPT_num_threads = 2;
string OPT_dir_out;

//
// thread body
//

struct StatWorker
{

    StatWorker(int thread_id) : thread_id(thread_id)
    {
    }

    void operator() ()
    {
        while (1)
        {
            // get index of the todo read
            size_t read_i = i_todo.pop();

            // exit when get the signal
            if (read_i == OPT_num_threads) break;

            // record this seq
            if (OPT_paired)
            {
                stats_a[thread_id].record_seq(reads_a[read_i]);
                stats_b[thread_id].record_seq(reads_b[read_i]);
            }
            else if (OPT_single)
            {
                stats_a[thread_id].record_seq(reads_a[read_i]);
            }


            // push back processed read slot
            i_done.push(read_i);
        }
    }

    int thread_id;
};

//
// functions
//

void write_cycle_quality_table(const string& file, const FastqStat& stat)
{
    ofstream OUT(file.c_str());

    // write header
    OUT << "#cycle";
    for (int q = stat.qual_from; q <= stat.qual_to; q++)
        OUT << "\t" << q;
    OUT << endl;

    // write qualities for each cycle
    for (int i = 0; i < stat.observed_max_len; i++)
    {
        const BaseQualCounter& quals = stat.base_qual_counter[i];
        OUT << i + 1;
        for (int q = stat.qual_from; q <= stat.qual_to; q++)
            OUT << "\t" << quals.get_num(q);
        OUT << endl;
    }
}

void write_cycle_quality_box(const string& file, const FastqStat& stat)
{
    ofstream OUT(file.c_str());

    // write header
    OUT << "#cycle\tdec low\tquad low\tmedian\tquad high\tdec high\tmean" << endl;

    // write quality distribution for each cycle
    for (int i = 0; i < stat.observed_max_len; i++)
    {
        const BaseQualCounter& quals = stat.base_qual_counter[i];
        BaseQualBoxChart chart = {0, 0, 0, 0, 0, 0};
        quals.create_chart(chart);
        OUT << i + 1 << "\t" << chart.dec_low << "\t" << chart.quat_low << "\t" << chart.median << "\t" << chart.quat_high << "\t" << chart.dec_high << "\t" << chart.mean << endl;
    }
}

void write_cycle_composition(const string& file, const FastqStat& stat, bool qual_mask)
{
    ofstream OUT(file.c_str());

    // write header
    OUT << "cycle" << "\t" << "A" << "\t" << "T" << "\t" << "G" << "\t" << "C" << "\t" << "N";
    if (qual_mask) OUT << "\t" << "mask";
    OUT << endl;

    // write composition for each cycle
    for (int i = 0; i < stat.observed_max_len; i++)
    {
        const BaseCounter& counter = stat.base_compo_counter[i];
        OUT << i + 1 << "\t"
            << counter.a << "\t"
            << counter.t << "\t"
            << counter.g << "\t"
            << counter.c << "\t"
            << counter.n << "\t";
        if (qual_mask) OUT << counter.mask;
        OUT << endl;
    }
}

void write_se_seq_quality(const string& file, const FastqStat& stat)
{
    ofstream OUT(file.c_str());

    // write header
    OUT << "#quality\tread 1 num\tread 1 accumulate" << endl;

    int q = stat.qual_from;
    int val_a = 0;
    int sum_a = 0;

    while (1)
    {
        if (q > stat.qual_to) break;

        val_a = stat.read_qual_counter.get_num(q);
        sum_a += val_a;
        OUT << q << "\t" << val_a << "\t" << sum_a << endl;

        q++;
    }

}

void write_pe_seq_quality(const string& file, const FastqStat& stat_a, const FastqStat& stat_b)
{
    ofstream OUT(file.c_str());

    // write header
    OUT << "#quality\tread 1 num\tread 1 accumulate\tread 2 num\tread 2 accumulate" << endl;

    int q = stat_a.qual_from;
    int val_a = 0;
    int sum_a = 0;
    int val_b = 0;
    int sum_b = 0;

    while (1)
    {
        if (q > stat_a.qual_to) break;

        val_a = stat_a.read_qual_counter.get_num(q);
        val_b = stat_b.read_qual_counter.get_num(q);
        sum_a += val_a;
        sum_b += val_b;

        OUT << q << "\t" << val_a << "\t" << sum_a << "\t" << val_b << "\t" << sum_b << endl;

        q++;
    }
}

void write_se_seq_length(const string& file, const FastqStat& stat)
{
    ofstream OUT(file.c_str());

    // write header
    OUT << "#length" << "\t" << "read 1 num" << "\t" << "read 1 accumulate" << endl;

    {
        int i = 1;
        int val_a = 0;
        int sum_a = 0;

        while (1)
        {
            if (i > stat.observed_max_len) break;

            val_a = stat.read_len_counter[i];
            sum_a += val_a;
            OUT << i << "\t" << val_a << "\t" << sum_a << endl;

            i++;
        }
    }
}

void write_pe_seq_length(const string& file, const FastqStat& stat_a, const FastqStat& stat_b)
{
    ofstream OUT(file.c_str());

    // write header
    if (stat_a.observed_max_len != stat_b.observed_max_len)
    {
        cerr << "store has inequal length: " << stat_a.observed_max_len << " and " << stat_b.observed_max_len << endl;
        exit(EXIT_FAILURE);
    }

    size_t length = stat_a.observed_max_len;

    OUT << "#length" << "\t" << "read 1 num" << "\t" << "read 1 accumulate" << "\t" << "read 2 num" << "\t" << "read 2 accumulate" << endl;

    {
        int i = 1;
        int val_a = 0;
        int sum_a = 0;
        int val_b = 0;
        int sum_b = 0;

        while (1)
        {
            if (i > length) break;

            val_a = stat_a.read_len_counter[i];
            val_b = stat_b.read_len_counter[i];
            sum_a += val_a;
            sum_b += val_b;

            OUT << i << "\t" << val_a << "\t" << sum_a << "\t" << val_b << "\t" << sum_b << endl;

            i++;
        }
    }
}

void write_lane_tile_quality(const string& file, const FastqStat& stat)
{
    ofstream OUT(file.c_str());

    // write header
    OUT << "#lane\ttile\tqual<10\t10<qual<20\t20<qual<30\tqual>30" << endl;

    // write content
    for (
         map< int, map<int, TileQualCounter> >::const_iterator it_lane = stat.tile_read_qual_counter.begin();
         it_lane != stat.tile_read_qual_counter.end();
         it_lane++
         )
    {
        const map<int, TileQualCounter>* lane_quals = &(it_lane->second);

        for (
             map<int, TileQualCounter>::const_iterator it_tile = lane_quals->begin();
             it_tile != lane_quals->end();
             it_tile++
             )
        {
            const TileQualCounter* tile_quals = &(it_tile->second);
            OUT << it_lane->first << "\t"
                << it_tile->first << "\t"
                << tile_quals->num_reads_10 << "\t"
                << tile_quals->num_reads_10_20 << "\t"
                << tile_quals->num_reads_20_30 << "\t"
                << tile_quals->num_reads_30 << endl;
        }
    }
}

void write_qq(const string& file, const FastqStat& stat_a, const FastqStat& stat_b)
{
    ofstream OUT(file.c_str());

    // calculate pearson correlation
    size_t n = stat_a.read_quals.size();

    double sum_xy(0);
    double sum_x(0);
    double sum_y(0);
    double sum_xx(0);
    double sum_yy(0);

    for (size_t i = 0; i < n; i++)
    {
        float x = stat_a.read_quals[i];
        float y = stat_b.read_quals[i];
        sum_xy += x*y;
        sum_x += x;
        sum_y += y;
        sum_xx += x*x;
        sum_yy += y*y;
    }

    double pearson =
        (
         n * sum_xy - sum_x * sum_y
         ) / (
              sqrt(n * sum_xx - sum_x * sum_x) * sqrt(n * sum_yy - sum_y * sum_y)
              );

    vector<float> quals_a_sorted = stat_a.read_quals;
    vector<float> quals_b_sorted = stat_b.read_quals;
    sort(quals_a_sorted.begin(), quals_a_sorted.end());
    sort(quals_b_sorted.begin(), quals_b_sorted.end());
    int num_seq = stat_a.read_quals.size();
    int step = num_seq / 200;

    OUT << "# pearson correlation: " << pearson << endl;

    // write data
    for (int i = 0; i < num_seq; i += step)
    {
        OUT << quals_a_sorted[i] << "\t" << quals_b_sorted[i] << endl;
    }
}

//
// main
//

void parse_options(int argc, char** argv)
{
    opt::options_description group_main("Options:");
    group_main.add_options()
    OPT_files_in_ENTRY
    OPT_single_ENTRY
    OPT_paired_ENTRY
        ("out,o", opt::value<string > (&OPT_dir_out), "output directory for quality reports.")
        ("threads,t", opt::value<int> (&OPT_num_threads)->default_value(2), "Number of worker threads.");

    opt::options_description group_misc("Misc options:");
    group_misc.add_options()
    OPT_encode_ENTRY
    OPT_header_format_ENTRY
    OPT_header_sra_ENTRY
    OPT_mask_ENTRY
    OPT_gzip_ENTRY
    OPT_quiet_ENTRY
    OPT_help_ENTRY
    OPT_version_ENTRY;
    group_main.add(group_misc);

    opt::variables_map var_map;
    opt::store(opt::parse_command_line(argc, argv, group_main), var_map);
    opt::notify(var_map);

    //
    // show help
    //
    if (OPT_help)
    {
        cout << endl
            << argv[0] << " - summarize sequencing reads quality"
            << endl << endl
            << group_main;
        exit(EXIT_SUCCESS);
    }

    if (OPT_version) show_version_and_exit();

    //
    // validate options
    //
    check_single_paired();

    if ((OPT_encode == HTIO_ENCODE_SOLEXA) && OPT_mask)
    {
        cerr << "solexa mode cannot be used together with mask" << endl;
        exit(EXIT_FAILURE);
    }

    //
    // guess quality encoding
    //
    if (OPT_encode == HTIO_ENCODE_AUTO)
    {
        if (!OPT_quiet) cout << "guess encode from front " << NUM_GUESS << " sequences of file " << OPT_files_in[0] << endl;
        FastqIO fh(OPT_files_in[0], HTIO_READ, OPT_gzip);
        OPT_encode = guess_quality_encode(fh, NUM_GUESS);
        if (OPT_encode == HTIO_ENCODE_UNKNOWN || OPT_encode == HTIO_ENCODE_AUTO)
        {
            cerr << "failed to guess quality encode from input file " << OPT_files_in[0] << endl;
            exit(EXIT_FAILURE);
        }
    }

    //
    // guess header format
    //
    if (OPT_header_format == HTIO_HEADER_AUTO)
    {
        if (!OPT_quiet) cout << "guess header format from front " << NUM_GUESS << " sequences of file " << OPT_files_in[0] << endl;
        FastqIO fh(OPT_files_in[0], HTIO_READ, OPT_gzip);
        guess_header_format(fh, NUM_GUESS, OPT_header_format, OPT_header_sra);

        if (OPT_header_format == HTIO_HEADER_UNKNOWN &&!OPT_quiet)
            cout << "failed to guess header format, lane and tile quality will not be summarized" << endl;
    }
}

void log_header()
{
    show_single_paired();
    show_files_in();
    cout << "# output directory: " << OPT_dir_out << endl;
    show_encode();
    show_header_format();
    show_mask();
}

size_t do_single()
{
    long num_processed = 0;
    int read_i;

    FastqSeq curr;

    for (size_t file_i = 0; file_i < OPT_files_in.size(); file_i++)
    {
        cout << OPT_files_in[file_i] << endl;
        FastqIO IN(OPT_files_in[file_i], HTIO_READ, OPT_gzip);

        while (1)
        {
            // read sequence
            if (!IN.next_seq(curr)) break;

            // get empty slot
            read_i = i_done.pop();
            reads_a[read_i] = curr;

            // send current slot
            i_todo.push(read_i);

            num_processed++;
            if (!OPT_quiet && (num_processed % LOG_BLOCK == 0))
                cout << "\t" << num_processed << " reads done" << endl;
        } // sequence cycle
    } // file cycle

    if (!OPT_quiet) cout << "\t" << num_processed << " done" << endl;
    return num_processed;
}

size_t do_paired()
{
    vector<string> files_in_a;
    vector<string> files_in_b;
    separate_paired_files(OPT_files_in, files_in_a, files_in_b);

    if (!OPT_quiet)
    {

    }

    long num_processed = 0;
    int read_i;

    FastqSeq curr_a;
    FastqSeq curr_b;

    for (size_t file_i = 0; file_i < files_in_a.size(); file_i++)
    {
        cout << files_in_a[file_i] << " and " << files_in_b[file_i] << endl;
        FastqIO IN_A(files_in_a[file_i], HTIO_READ, OPT_gzip);
        FastqIO IN_B(files_in_b[file_i], HTIO_READ, OPT_gzip);

        while (1)
        {
            // read sequence
            bool re_a = IN_A.next_seq(curr_a);
            bool re_b = IN_B.next_seq(curr_b);
            if (re_a)
            {
                if (re_b);
                else
                {
                    cerr << "input file B finished, but input file A not" << endl
                        << files_in_a[file_i] << " and " << files_in_b[file_i] << endl;
                    exit(EXIT_FAILURE);
                }
            }
            else
            {
                if (re_b)
                {
                    cerr << "input file A finished, but input file B not" << endl
                        << files_in_a[file_i] << " and " << files_in_b[file_i] << endl;
                    exit(EXIT_FAILURE);
                }
                else
                {
                    break;
                }
            }

            // get empty slot
            read_i = i_done.pop();
            reads_a[read_i] = curr_a;
            reads_b[read_i] = curr_b;

            // send slot
            i_todo.push(read_i);

            num_processed++;
            if (!OPT_quiet && (num_processed % LOG_BLOCK == 0))
                cout << "\t" << num_processed << " pairs done" << endl;
        } // sequence cycle
    } // file cycle

    if (!OPT_quiet) cout << "\t" << num_processed << " done" << endl;
    return num_processed;
}

int main(int argc, char** argv)
{
    // parse command-line arguments
    parse_options(argc, argv);

    if (!OPT_quiet) log_header();

    // create output directory
    boost::filesystem::path dir_out(OPT_dir_out);
    if (!boost::filesystem::is_directory(dir_out))
    {
        boost::filesystem::create_directory(dir_out);
    }

    //
    // create thread communication utilities
    //
    reads_a.resize(OPT_num_threads, FastqSeq());
    reads_b.resize(OPT_num_threads, FastqSeq());
    stats_a.resize(OPT_num_threads, FastqStat(OPT_mask, OPT_encode, OPT_header_format, OPT_header_sra));
    stats_b.resize(OPT_num_threads, FastqStat(OPT_mask, OPT_encode, OPT_header_format, OPT_header_sra));

    // mark all slots as ready to use
    for (size_t i = 0; i < OPT_num_threads; i++)
        i_done.push(i);

    // create threads
    for (size_t i = 0; i < OPT_num_threads; i++)
    {
        workers.push_back(new StatWorker(i));
        threads.push_back(new boost::thread(boost::ref(*workers[i])));
    }

    //
    // traverse input
    //
    size_t num_processed = 0;

    if (OPT_paired) num_processed = do_paired();
    else if (OPT_single) num_processed = do_single();
    else throw runtime_error("neither single nor paired");

    // join threads
    // reduce statistic results from all threads into one
    for (int i = 0; i < OPT_num_threads; i++)
        i_todo.push(OPT_num_threads);

    FastqStat stat_a(OPT_mask, OPT_encode, OPT_header_format, OPT_header_sra);
    FastqStat stat_b(OPT_mask, OPT_encode, OPT_header_format, OPT_header_sra);

    if (!OPT_quiet) cout << "join threads" << endl;
    for (int i = 0; i < OPT_num_threads; i++)
    {
        if (!OPT_quiet) cout << "  thread " << i << endl;
        threads[i]->join();

        if (stats_a[i].observed_max_len < stat_a.observed_max_len)
            stats_a[i].try_expand_store(stat_a.observed_max_len);
        stat_a += stats_a[i];

        if (OPT_paired)
        {
            if (stats_b[i].observed_max_len < stat_b.observed_max_len)
                stats_b[i].try_expand_store(stat_b.observed_max_len);
            stat_b += stats_b[i];
        }

        delete threads[i];
        delete workers[i];
    }

    if (OPT_paired)
    {
        if (stat_a.observed_max_len > stat_b.observed_max_len)
            stat_b.try_expand_store(stat_a.observed_max_len);
        else
            stat_a.try_expand_store(stat_b.observed_max_len);
    }

    //
    // write result
    //
    if (!OPT_quiet) cout << "write result" << endl;

    // reads info
    boost::filesystem::path file_info = dir_out / boost::filesystem::path("info.tab");
    ofstream INFO(file_info.c_str());
    INFO << "amount" << "\t" << num_processed << (OPT_paired ? "x2" : "") << endl
        << "encode" << "\t" << encode_to_string(OPT_encode) << endl
        << "paired" << "\t" << bool_to_string(OPT_paired) << endl
        << "length" << "\t" << stat_a.observed_max_len << endl
        << "mask" << "\t" << bool_to_string(OPT_mask) << endl
        << "quality range" << "\t" << stat_a.qual_from << '-' << stat_a.qual_to << endl;

    // cycle quality
    fs::path file_cycle_qual_1 = dir_out / fs::path("cycle_quality_1.tab");
    fs::path file_cycle_qual_box_1 = dir_out / fs::path("cycle_quality_box_1.tab");
    if (!OPT_quiet)
        cout << "  " << file_cycle_qual_1 << endl
        << "  " << file_cycle_qual_box_1 << endl;

    write_cycle_quality_table(file_cycle_qual_1.string(), stat_a);
    write_cycle_quality_box(file_cycle_qual_box_1.string(), stat_a);

    if (OPT_paired)
    {
        fs::path file_cyc_qual_2 = dir_out / fs::path("cycle_quality_2.tab");
        fs::path file_cyc_qual_box_2 = dir_out / fs::path("cycle_quality_box_2.tab");
        if (!OPT_quiet)
            cout << "  " << file_cyc_qual_2 << endl
            << "  " << file_cyc_qual_box_2 << endl;

        write_cycle_quality_table(file_cyc_qual_2.string(), stat_b);
        write_cycle_quality_box(file_cyc_qual_box_2.string(), stat_b);
    }

    // read quality
    fs::path file_read_qual = dir_out / "reads_quality.tab";
    if (!OPT_quiet) cout << "  " << file_read_qual << endl;

    if (OPT_paired)
    {
        write_pe_seq_quality(file_read_qual.string(), stat_a, stat_b);
    }
    else
    {
        write_se_seq_quality(file_read_qual.string(), stat_a);
    }

    // lane and tile quality
    fs::path file_lane_tile_qual_1 = dir_out / fs::path("lane_tile_quality_1.tab");
    if (!OPT_quiet) cout << "  " << file_lane_tile_qual_1 << endl;
    write_lane_tile_quality(file_lane_tile_qual_1.string(), stat_a);

    if (OPT_paired)
    {
        fs::path file_lane_tile_qual_2 = dir_out / fs::path("lane_tile_quality_2.tab");
        if (!OPT_quiet) cout << "  " << file_lane_tile_qual_2 << endl;
        write_lane_tile_quality(file_lane_tile_qual_2.string(), stat_b);
    }

    // cycle composition
    fs::path file_cycle_comp_1 = dir_out / fs::path("cycle_composition_1.tab");
    if (!OPT_quiet) cout << "  " << file_cycle_comp_1 << endl;
    write_cycle_composition(file_cycle_comp_1.string(), stat_a, OPT_mask);

    if (OPT_paired)
    {
        fs::path file_cycle_comp_2 = dir_out / fs::path("cycle_composition_2.tab");
        if (!OPT_quiet) cout << "  " << file_cycle_comp_2 << endl;
        write_cycle_composition(file_cycle_comp_2.string(), stat_b, OPT_mask);
    }

    // read length
    fs::path file_read_length = dir_out / fs::path("reads_length.tab");
    if (!OPT_quiet) cout << "  " << file_read_length << endl;

    if (OPT_paired)
    {
        write_pe_seq_length(file_read_length.string(), stat_a, stat_b);
    }
    else
    {
        write_se_seq_length(file_read_length.string(), stat_a);
    }

    // QQ plot
    if (OPT_paired)
    {
        fs::path file_qual_qq = dir_out / fs::path("quality_QQ.tab");
        if (!OPT_quiet) cout << "  " << file_qual_qq << endl;
        write_qq(file_qual_qq.string(), stat_a, stat_b);
    }

    if (!OPT_quiet) cout << "done" << endl;
}


