/*
 * File:   FastaSeq.cpp
 * Author: yangxi
 *
 * Created on December 25, 2012, 3:15 PM
 */

#include "htio1/SimpleSeq.h"

namespace htio
{

SimpleSeq::SimpleSeq()
{
}

SimpleSeq::SimpleSeq(const std::string& id, const std::string& desc, const std::string& seq) :
id(id),
desc(desc),
seq(seq)
{
}

SimpleSeq::~SimpleSeq()
{
}

void SimpleSeq::revcom(SimpleSeq& result) const
{
    result.id = id;
    result.desc = desc;
    htio::revcom(seq, result.seq);
}

void SimpleSeq::subseq(SimpleSeq& result, size_t start, size_t length) const
{
    result.id = id;
    result.desc = desc;
    result.seq.assign(seq, start, length);
}

} // namespace htio
