#include "htqc/SeqFilter.h"

#define USE_prefix_out
#define USE_encode
#define USE_mask
#define USE_header_format
#define USE_single_paired
#include "htqc/Options.h"

#include "htio1/FastqIO.h"
#include "htio1/QualityUtil.h"

using namespace std;
using namespace htio;
using namespace htqc;

typedef std::string OPT_filter_TYPE;
OPT_filter_TYPE OPT_filter;
#define OPT_filter_KEY "filter,F"
#define OPT_filter_DESC "length/tile/quality"

typedef int OPT_cut_len_TYPE;
OPT_cut_len_TYPE OPT_cut_len;
#define OPT_cut_len_KEY "cut-length,L"
#define OPT_cut_len_DESC "length cutoff"
#define OPT_cut_len_DEFAULT 50

typedef int OPT_cut_qual_TYPE;
OPT_cut_qual_TYPE OPT_cut_qual;
#define OPT_cut_qual_KEY "cut-quality,Q"
#define OPT_cut_qual_DESC "quality cutoff"
#define OPT_cut_qual_DEFAULT 20

typedef vector<int> OPT_rej_tiles_TYPE;
OPT_rej_tiles_TYPE OPT_rej_tiles;
#define OPT_rej_tiles_KEY "reject-tiles,T"
#define OPT_rej_tiles_DESC "tiles to reject"

SeqFilter* filter;

void parse_options(int argc, char** argv)
{
    opt::options_description opt_main("Options");
    opt_main.add_options()
    OPT_files_in_ENTRY
    OPT_prefix_out_ENTRY
    OPT_single_ENTRY
    OPT_paired_ENTRY;

    opt::options_description opt_filter("Filter options");
    opt_filter.add_options()
        (OPT_filter_KEY, opt::value<OPT_filter_TYPE > (&OPT_filter), OPT_filter_DESC)
        (OPT_cut_len_KEY, opt::value<OPT_cut_len_TYPE > (&OPT_cut_len)->default_value(OPT_cut_len_DEFAULT), OPT_cut_len_DESC)
        (OPT_cut_qual_KEY, opt::value<OPT_cut_qual_TYPE > (&OPT_cut_qual)->default_value(OPT_cut_qual_DEFAULT), OPT_cut_qual_DESC)
        (OPT_rej_tiles_KEY, opt::value<OPT_rej_tiles_TYPE > (&OPT_rej_tiles)->multitoken(), OPT_rej_tiles_DESC);
    opt_main.add(opt_filter);


    opt::options_description opt_misc("Misc options");
    opt_misc.add_options()
    OPT_encode_ENTRY
    OPT_mask_ENTRY
    OPT_header_format_ENTRY
    OPT_header_sra_ENTRY
    OPT_gzip_ENTRY
    OPT_quiet_ENTRY
    OPT_help_ENTRY
    OPT_version_ENTRY;
    opt_main.add(opt_misc);

    opt::variables_map var_map;
    opt::store(opt::parse_command_line(argc, argv, opt_main), var_map);
    opt::notify(var_map);

    // show help
    if (OPT_help)
    {
        cout << endl
            << argv[0] << " - filter sequences using various criteria"
            << endl << endl
            << opt_main;
        exit(EXIT_SUCCESS);
    }

    if (OPT_version) show_version_and_exit();

    //
    // validate options
    //
    check_single_paired();

    // output prefix
    if (OPT_prefix_out.length() == 0)
    {
        cerr << "output prefix not specified!" << endl;
        exit(EXIT_FAILURE);
    }
    tidy_prefix_out(OPT_prefix_out);

    //
    // guess quality encoding
    //
    if (OPT_encode == HTIO_ENCODE_AUTO)
    {
        if (!OPT_quiet) cout << "guess quality encode from front " << NUM_GUESS << " sequences of file " << OPT_files_in[0] << endl;
        FastqIO fh(OPT_files_in[0], HTIO_READ, OPT_gzip);
        OPT_encode = guess_quality_encode(fh, NUM_GUESS);
        if (OPT_encode == HTIO_ENCODE_UNKNOWN || OPT_encode == HTIO_ENCODE_AUTO)
        {
            cerr << "failed to guess quality encode from input file " << OPT_files_in[0] << endl;
            exit(EXIT_FAILURE);
        }
        if (!OPT_quiet) cout << "quality encode is " << cast<string>(OPT_encode) << endl;
    }

    //
    // create filter
    //
    if (OPT_filter == "quality")
    {
        filter = static_cast<SeqFilter*> (new SeqFilterQuality(OPT_cut_qual, OPT_encode, OPT_mask));
    }
    else if (OPT_filter == "length")
    {
        filter = static_cast<SeqFilter*> (new SeqFilterLength(OPT_cut_len, OPT_encode, OPT_mask));
    }
    else if (OPT_filter == "tile")
    {
        // guess header format
        if (OPT_header_format == HTIO_HEADER_AUTO)
        {
            if (!OPT_quiet) cout << "guess header format from front " << NUM_GUESS << " sequences of file " << OPT_files_in[0] << endl;
            FastqIO fh(OPT_files_in[0], HTIO_READ, OPT_gzip);
            guess_header_format(fh, NUM_GUESS, OPT_header_format, OPT_header_sra);
            if (OPT_header_format == HTIO_HEADER_UNKNOWN || OPT_header_format == HTIO_HEADER_AUTO)
            {
                cerr << "failed to guess header format from input file " << OPT_files_in[0] << endl;
                exit(EXIT_FAILURE);
            }
            if (!OPT_quiet)
            {
                cout << "header format is " << cast<string>(OPT_header_format);
                if (OPT_header_sra) cout << ", with SRA" << endl;
                else cout << ", without SRA" << endl;
            }
        }

        // create filter
        SeqFilterTile* filter_tmp = new SeqFilterTile(OPT_header_format, OPT_header_sra);
        filter = static_cast<SeqFilter*> (filter_tmp);

        for (size_t i = 0; i < OPT_rej_tiles.size(); i++)
        {
            // parse int from string
            int tile = OPT_rej_tiles[i];

            // try to insert to tileset
            pair < RejTileMap::iterator, bool> re = filter_tmp->rej_tiles.insert(RejTileKV(tile, 0));
            if (!re.second)
            {
                cerr << "tile list have duplicate values: " << tile << endl;
                exit(EXIT_FAILURE);
            }
        }
    }
    else
    {
        cerr << "invalid filter type: " << OPT_filter << ", must be quality|length|tile" << endl;
        exit(EXIT_FAILURE);
    }

}

void log_header()
{
    show_single_paired();
    show_files_in();
    show_prefix_out();
    cout << "# filter: " << OPT_filter << endl;
    if (OPT_filter == "quality")
    {
        show_encode();
        cout << "# quality cutoff: " << OPT_cut_qual << endl;
    }
    else if (OPT_filter == "length")
    {
        show_encode();
        cout << "# length cutoff: " << OPT_cut_len << endl;
    }
    else if (OPT_filter == "tile")
    {
        show_header_format();
        cout << "# tiles to reject:";
        for (size_t i = 0; i < OPT_rej_tiles.size(); i++)
            cout << " " << OPT_rej_tiles[i];
        cout << endl;
    }
}

void filter_se()
{
    string file_out = string(OPT_prefix_out) + ".fastq";
    if (OPT_gzip) file_out += ".gz";

    // check if output file is same with any input file
    for (size_t i = 0; i < OPT_files_in.size(); i++)
    {
        if (OPT_files_in[i] == file_out)
        {
            cerr << "output file will overwrite input file: " << file_out << endl;
            exit(EXIT_FAILURE);
        }
    }

    FastqIO OUT(file_out, HTIO_WRITE, OPT_gzip);

    // traverse input
    FastqSeq curr_seq;
    int64_t n_accept = 0;
    int64_t n_seq = 0;

    for (size_t i = 0; i < OPT_files_in.size(); i++)
    {
        FastqIO IN(OPT_files_in[i], HTIO_READ, OPT_gzip);

        while (IN.next_seq(curr_seq))
        {
            n_seq++;

            if (filter->check(curr_seq))
            {
                OUT.write_seq(curr_seq);
                n_accept++;
            }

            if (!OPT_quiet && (n_seq % LOG_BLOCK == 0))
                cout << "\t" << n_seq << " reads, " << n_accept << " accept" << endl;
        }
    }
    if (!OPT_quiet)
        cout << "\t" << n_seq << " reads, " << n_accept << " accept" << endl;
}

void filter_pe()
{
    vector<string> files_in_a;
    vector<string> files_in_b;
    separate_paired_files(OPT_files_in, files_in_a, files_in_b);

    string file_out_a = string(OPT_prefix_out) + "_1.fastq";
    string file_out_b = string(OPT_prefix_out) + "_2.fastq";
    string file_out_s = string(OPT_prefix_out) + "_s.fastq";
    if (OPT_gzip)
    {
        file_out_a += ".gz";
        file_out_b += ".gz";
        file_out_s += ".gz";
    }

    // check if output file is same with any input file
    for (size_t i = 0; i < files_in_a.size(); i++)
    {
        if (files_in_a[i] == file_out_a || files_in_b[i] == file_out_a)
        {
            cerr << "output file will overwrite input file: " << file_out_a << endl;
            exit(EXIT_FAILURE);
        }
        if (files_in_a[i] == file_out_b || files_in_b[i] == file_out_b)
        {
            cerr << "output file will overwrite input file: " << file_out_b << endl;
            exit(EXIT_FAILURE);
        }
        if (files_in_a[i] == file_out_s || files_in_b[i] == file_out_s)
        {
            cerr << "output file will overwrite input file: " << file_out_s << endl;
            exit(EXIT_FAILURE);
        }
    }

    FastqIO OUT_A(file_out_a, HTIO_WRITE, OPT_gzip);
    FastqIO OUT_B(file_out_b, HTIO_WRITE, OPT_gzip);
    FastqIO OUT_S(file_out_s, HTIO_WRITE, OPT_gzip);

    FastqSeq curr_seq_a;
    FastqSeq curr_seq_b;

    int64_t n_accept_pair = 0;
    int64_t n_accept_single = 0;
    int64_t n_pair = 0;

    for (size_t i = 0; i < files_in_a.size(); i++)
    {
        FastqIO IN_A(files_in_a[i], HTIO_READ, OPT_gzip);
        FastqIO IN_B(files_in_b[i], HTIO_READ, OPT_gzip);
        while (1)
        {
            bool re_a = IN_A.next_seq(curr_seq_a);
            bool re_b = IN_B.next_seq(curr_seq_b);

            if (re_a)
            {
                if (re_b);
                else
                {
                    cerr << "input file B finished, but input file A not" << endl
                        << files_in_a[i] << " and " << files_in_b[i] << endl;
                    exit(EXIT_FAILURE);
                }
            }
            else
            {
                if (re_b)
                {
                    cerr << "input file A finished, but input file B not" << endl
                        << files_in_a[i] << " and " << files_in_b[i] << endl;
                    exit(EXIT_FAILURE);
                }
                else
                    break;
            }

            n_pair++;



            bool accept_a = filter->check(curr_seq_a);
            bool accept_b = filter->check(curr_seq_b);

            if (accept_a)
            {
                if (accept_b)
                {
                    OUT_A.write_seq(curr_seq_a);
                    OUT_B.write_seq(curr_seq_b);
                    n_accept_pair++;
                }
                else
                {
                    OUT_S.write_seq(curr_seq_a);
                    n_accept_single++;
                }
            }
            else
            {
                if (accept_b)
                {
                    OUT_S.write_seq(curr_seq_b);
                    n_accept_single++;
                }
            }

            if (!OPT_quiet && (n_pair % LOG_BLOCK == 0))
                cout << "\t" << n_pair << " pairs, " << n_accept_pair << " accept by pair, " << n_accept_single << " accept by single" << endl;
        }
    }
    cout << "\t" << n_pair << " pairs, " << n_accept_pair << " accept by pair, " << n_accept_single << " accept by single" << endl;
}

int main(int argc, char** argv)
{
    parse_options(argc, argv);

    if (!OPT_quiet)
        log_header();

    if (OPT_paired)
        filter_pe();
    else if (OPT_single)
        filter_se();
    else
    {
        cerr << "neither single nor paired" << endl;
        exit(EXIT_FAILURE);
    }

    if (!OPT_quiet)
        cout << "done" << endl;
}
