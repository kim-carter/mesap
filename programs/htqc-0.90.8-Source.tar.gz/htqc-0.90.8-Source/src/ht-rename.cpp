#include "htio1/FastqIO.h"
#include "htio1/FastqSeq.h"

#define USE_file_out
#define USE_single_paired
#include "htqc/Options.h"

#include <sstream>

using namespace std;
using namespace htqc;

string OPT_prefix;
string OPT_suffix;
bool keep_desc;

void parse_options(int argc, char** argv)
{
    opt::options_description group_main("Options:");
    group_main.add_options()
    OPT_files_in_ENTRY
    OPT_file_out_ENTRY
            ("prefix", opt::value<std::string > (&OPT_prefix), "Prefix for generated IDs.")
            ("suffix", opt::value<std::string > (&OPT_suffix), "Suffix for generated IDs.")
            ("keep-desc", opt::bool_switch(&keep_desc), "Keep reads description in output (header content after the first continuous blank).");

    opt::options_description group_misc("Misc options");
    group_misc.add_options()
    OPT_gzip_ENTRY
    OPT_quiet_ENTRY
    OPT_help_ENTRY
    OPT_version_ENTRY;
    group_main.add(group_misc);

    opt::variables_map var_map;
    opt::store(opt::parse_command_line(argc, argv, group_main), var_map);
    opt::notify(var_map);

    // we are always processing single
    OPT_single = true;

    //
    // show help
    //
    if (OPT_help)
    {
        cout << endl
                << argv[0] << " - generate simple sequence IDs by batch"
                << endl << endl
                << group_main;
        exit(EXIT_SUCCESS);
    }

    if (OPT_version) show_version_and_exit();

    // validate options
    if (OPT_file_out.length() == 0)
    {
        cerr << "output file not specified!" << endl;
        exit(EXIT_FAILURE);
    }

    if (OPT_prefix.length() == 0 && OPT_suffix.length() == 0)
    {
        cerr << "WARNING: neither prefix nor suffix was provided!" << endl;
    }

}

int main(int argc, char** argv)
{
    // parse and show options
    parse_options(argc, argv);

    if (!OPT_quiet)
    {
        show_files_in();
        show_file_out();
        cout << "# new IDs as: " << OPT_prefix << "(NUMBER)" << OPT_suffix;
        if (keep_desc) cout << " DESCRIPTION";
        cout << endl;
    }

    // output handle
    htio::FastqIO OUT(OPT_file_out, htio::HTIO_WRITE, OPT_gzip);

    // traverse input files
    if (!OPT_quiet) cout << "process sequences" << endl;
    size_t num_seq = 0;
    htio::FastqSeq curr_seq;

    for (size_t i = 0; i < OPT_files_in.size(); i++)
    {
        if (!OPT_quiet) cout << "  " << OPT_files_in[i] << endl;
        htio::FastqIO IN(OPT_files_in[i], htio::HTIO_READ, OPT_gzip);

        while (IN.next_seq(curr_seq))
        {
            num_seq++;
            if (!OPT_quiet && num_seq % LOG_BLOCK == 0)
                cout << "    " << num_seq << " sequences processed" << endl;
            ostringstream id_new;
            id_new << OPT_prefix << num_seq << OPT_suffix;
            curr_seq.id = id_new.str();
            if (!keep_desc) curr_seq.desc = "";
            OUT.write_seq(curr_seq);
        }
    }

    if (!OPT_quiet) cout << "done: " << num_seq << " sequences processed" << endl;
}
