#include "htio1/FastqIO.h"
#include "htio1/FastqSeq.h"
#include "htio1/Kmer.h"

#define USE_prefix_out
#define USE_single_paired
#define USE_encode
#include "htqc/Options.h"
#include "htio1/FastaIO.h"
#include "htio1/QualityUtil.h"

using namespace std;
using namespace htqc;

string OPT_file_primer;
string OPT_prefix_fail;
bool OPT_check_revcom;
int OPT_mismatch_high;
int OPT_mismatch_low;
int OPT_tail_miss;
int OPT_cut_qual;

// primer data
vector<string> primers_left;
vector<string> primers_left_rev;
vector<string> primers_right;
vector<string> primers_right_rev;

vector<htio::KmerList> primers_left_klist;
vector<htio::KmerList> primers_left_rev_klist;
vector<htio::KmerList> primers_right_klist;
vector<htio::KmerList> primers_right_rev_klist;

vector<htio::KmerPosMap> primers_left_kpos;
vector<htio::KmerPosMap> primers_left_rev_kpos;
vector<htio::KmerPosMap> primers_right_kpos;
vector<htio::KmerPosMap> primers_right_rev_kpos;

void parse_options(int argc, char** argv)
{
    opt::options_description opt_main("Options");
    opt_main.add_options()
    OPT_files_in_ENTRY
    OPT_prefix_out_ENTRY
        ("fail,u", opt::value<string>(&OPT_prefix_fail), "Prefix for reads failed to trim.")
        ("primer", opt::value<string>(&OPT_file_primer), "Primers in FASTA format. IDs of left primers should begin with \"left\", and IDs for right primers should begin with \"right\".")
        OPT_single_ENTRY
        OPT_paired_ENTRY;

    opt::options_description opt_adv("Advanced options");
    opt_adv.add_options()
        ("check-revcom", opt::bool_switch(&OPT_check_revcom), "Also check primers in reverse complement direction.")
        ("tail-miss", opt::value<int>(&OPT_tail_miss)->default_value(5), "Allowed length of missing bases on primer 5'-end.")
        ("mismatch-high", opt::value<int>(&OPT_mismatch_high)->default_value(3), "Allowed number of mismatches on high-quality bases.")
        ("mismatch-low", opt::value<int>(&OPT_mismatch_low)->default_value(3), "Allowed number of mismatches on low-quality bases.")
        ("cut-qual", opt::value<int>(&OPT_cut_qual)->default_value(10), "Quality cutoff.");
    opt_main.add(opt_adv);

    opt::options_description opt_misc("Misc options");
    opt_misc.add_options()
    OPT_encode_ENTRY
    OPT_gzip_ENTRY
    OPT_quiet_ENTRY
    OPT_help_ENTRY
    OPT_version_ENTRY;
    opt_main.add(opt_misc);

    opt::variables_map var_map;
    opt::store(opt::parse_command_line(argc, argv, opt_main), var_map);
    opt::notify(var_map);

    // show help
    if (OPT_help)
    {
        cout << endl
            << argv[0] << " - remove primer sequence from reads"
            << endl << endl
            << opt_main;
        exit(EXIT_SUCCESS);
    }

    //
    // validate options
    //
    check_single_paired();

    // output prefix
    if (!OPT_prefix_out.length())
    {
        cerr << "output prefix not specified!" << endl;
        exit(EXIT_FAILURE);
    }
    tidy_prefix_out(OPT_prefix_out);

    // primer file
    if (!OPT_file_primer.length())
    {
        cerr << "primer file not specified!" << endl;
        exit(EXIT_FAILURE);
    }

    // failed seq output prefix
    if (OPT_prefix_fail.length())
        tidy_prefix_out(OPT_prefix_fail);

    //
    // guess quality encoding
    //
    if (OPT_encode == htio::HTIO_ENCODE_AUTO)
    {
        if (!OPT_quiet) cout << "guess quality encode from front " << NUM_GUESS << " sequences of file " << OPT_files_in[0] << endl;
        htio::FastqIO fh(OPT_files_in[0], htio::HTIO_READ, OPT_gzip);
        OPT_encode = htio::guess_quality_encode(fh, NUM_GUESS);
        if (OPT_encode == htio::HTIO_ENCODE_UNKNOWN || OPT_encode == htio::HTIO_ENCODE_AUTO)
        {
            cerr << "failed to guess quality encode from input file " << OPT_files_in[0] << endl;
            exit(EXIT_FAILURE);
        }
        if (!OPT_quiet) cout << "quality encode is " << htio::cast<string>(OPT_encode) << endl;
    }
}

void log_header()
{
    show_single_paired();
    show_files_in();
    show_prefix_out();
    cout << "# primers: " << OPT_file_primer << endl;
    if (OPT_prefix_fail.length())
        cout << "# output prefix for failed reads: " << OPT_prefix_fail << endl;
    cout << "# mismatch for high-quality bases: " << OPT_mismatch_high << endl;
    cout << "# mismatch for low-quality bases: " << OPT_mismatch_low << endl;
    cout << "# cutoff for low-quality bases: " << OPT_cut_qual << endl;
    show_encode();
}

size_t kmer_size = 0;

void read_primers()
{
    htio::FastaIO IN(OPT_file_primer, htio::HTIO_READ);
    htio::SimpleSeq seq;

    // read primers
    size_t shortest = 10000;
    if (!OPT_quiet)cout << "read primers" << endl;
    while (IN.next_seq(seq))
    {
        if (seq.id.find("left") == 0)
            primers_left.push_back(seq.seq);
        else if (seq.id.find("right") == 0)
        {
            primers_right.push_back(seq.seq);
        }
        else
        {
            cerr << "primer file has sequence with invalid ID: " << seq.id << endl
                << "IDs must begin with \"left\" or \"right\"" << endl;
            exit(EXIT_FAILURE);
        }
        if (seq.length() < shortest) shortest = seq.length();
    }

    size_t n_left = primers_left.size();
    size_t n_right = primers_right.size();

    if (n_left == 0 && n_right == 0)
    {
        cerr << "no sequence in primer file" << endl;
        exit(EXIT_FAILURE);
    }

    if (!OPT_quiet) cout << "  " << n_left << " left primers, " << n_right << " right primers" << endl;

    // automatically decide alignment kmer size
    kmer_size = (shortest - OPT_mismatch_high) / OPT_mismatch_high;
    if (kmer_size < 4) kmer_size = 4;
    if (!OPT_quiet) cout << "  shortest primer: " << shortest << ", alignment kmer size: " << kmer_size << endl;

    // preprocess primer data structure
    if (!OPT_quiet) cout << "  preprocess primer sequences" << endl;
    primers_left_rev.resize(n_left);
    primers_left_klist.resize(n_left);
    primers_left_rev_klist.resize(n_left);
    primers_left_kpos.resize(n_left);
    primers_left_rev_kpos.resize(n_left);

    for (size_t i = 0; i < n_left; i++)
    {
        // reverse complement
        htio::revcom(primers_left[i], primers_left_rev[i]);

        // kmer list
        htio::EncodedSeq enc_left;
        htio::EncodedSeq enc_left_rev;
        htio::encode_nt(primers_left[i], enc_left);
        htio::encode_nt(primers_left_rev[i], enc_left_rev);

        htio::gen_kmer_nt(enc_left, primers_left_klist[i], kmer_size);
        htio::gen_kmer_nt(enc_left_rev, primers_left_rev_klist[i], kmer_size);

        // kmer position map
        htio::summ_kmer_pos(primers_left_klist[i], primers_left_kpos[i]);
        htio::summ_kmer_pos(primers_left_rev_klist[i], primers_left_rev_kpos[i]);
    }

    primers_right_rev.resize(n_right);
    primers_right_klist.resize(n_right);
    primers_right_rev_klist.resize(n_right);
    primers_right_kpos.resize(n_right);
    primers_right_rev_kpos.resize(n_right);

    for (size_t i = 0; i < n_right; i++)
    {
        // reverse complement
        htio::revcom(primers_right[i], primers_right_rev[i]);

        // kmer list
        htio::EncodedSeq enc_right;
        htio::EncodedSeq enc_right_rev;
        htio::encode_nt(primers_right[i], enc_right);
        htio::encode_nt(primers_right_rev[i], enc_right_rev);

        htio::gen_kmer_nt(enc_right, primers_right_klist[i], kmer_size);
        htio::gen_kmer_nt(enc_right_rev, primers_right_rev_klist[i], kmer_size);

        // kmer position map
        htio::summ_kmer_pos(primers_right_klist[i], primers_right_kpos[i]);
        htio::summ_kmer_pos(primers_right_rev_klist[i], primers_right_rev_kpos[i]);
    }
}

bool align_primer(const string& read, const vector<int16_t>& read_qual, const vector<htio::KmerType>& seq_km_list,
                  const string& primer, const vector<htio::KmerType>& primer_km_list, const htio::KmerPosMap& primer_km_pos,
                  htio::PosType& seq_start, htio::PosType& seq_end,
                  htio::PosType& primer_start, htio::PosType& primer_end)
{
    const size_t len_seq = read.length();
    const size_t len_primer = primer.length();
    const size_t nk_seq = seq_km_list.size();

    bool success = false;

    // traverse sequence kmer position
    for (htio::PosType i_seq_km = 0; i_seq_km < nk_seq; i_seq_km++)
    {
        const htio::KmerType seq_km = seq_km_list[i_seq_km];
        pair<htio::KmerPosMap::const_iterator, htio::KmerPosMap::const_iterator> primer_km_pos_bound = primer_km_pos.equal_range(seq_km);

        // traverse primer kmer position
        for (htio::KmerPosMap::const_iterator primer_km_pos_it = primer_km_pos_bound.first;
             primer_km_pos_it != primer_km_pos_bound.second;
             primer_km_pos_it++)
        {
            const htio::PosType i_primer_km = primer_km_pos_it->second;

            const size_t len_seq_before = i_seq_km;
            const size_t len_primer_before = i_primer_km;

            // i_primer = i_seq + offset
            const htio::PosType offset = i_primer_km - i_seq_km;

            // get alignment start position
            htio::PosType i_seq_start = 0;
            htio::PosType i_primer_start = 0;
            if (len_seq_before < len_primer_before)
                i_primer_start = i_seq_start + offset;
            else
                i_seq_start = i_primer_start - offset;

            // traverse bases
            htio::PosType i_seq_end = i_seq_start;
            htio::PosType i_primer_end = i_primer_start;

            uint16_t mis_high = 0;
            uint16_t mis_low = 0;

            while (1)
            {
                if (read[i_seq_end] != primer[i_primer_end])
                {
                    if (read_qual[i_seq_end] >= OPT_cut_qual)
                        mis_high++;
                    else
                        mis_low++;
                }

                i_seq_end++;
                i_primer_end++;
                if (i_seq_end == len_seq || i_primer_end == len_primer) break;
            }

            // check status
            if (mis_high <= OPT_mismatch_high && mis_low <= OPT_mismatch_low)
            {
                success = true;
                seq_start = i_seq_start;
                seq_end = i_seq_end - 1;
                primer_start = i_primer_start;
                primer_end = i_primer_end - 1;
                break;
            }
        }

        if (success) break;
    }

    return success;
}

#define LEFT_START_OK  primer_start <= OPT_tail_miss
#define LEFT_END_OK primer_end + 1 == curr_primer_len
#define RIGHT_START_OK  primer_start == 0
#define RIGHT_END_OK curr_primer_len - primer_end - 1 <= OPT_tail_miss

void trim_se()
{
    string file_out = OPT_prefix_out + ".fastq";
    if (OPT_gzip) file_out += ".gz";

    string file_fail;
    if (OPT_prefix_fail.length())
    {
        file_fail = OPT_prefix_fail + ".fastq";
        if (OPT_gzip) file_fail += ".gz";
    }


    // check if output file is same with any input file
    for (size_t i = 0; i < OPT_files_in.size(); i++)
    {
        if (OPT_files_in[i] == file_out ||
            (OPT_prefix_fail.length() && OPT_files_in[i] == file_fail))
        {
            cerr << "output file will overwrite input file: " << file_out << endl;
            exit(EXIT_FAILURE);
        }
    }

    htio::FastqIO OUT(file_out, htio::HTIO_WRITE, OPT_gzip);
    htio::FastqIO* FAIL = NULL;
    if (OPT_prefix_fail.length())
        FAIL = new htio::FastqIO(file_fail, htio::HTIO_WRITE, OPT_gzip);

    // traverse input
    htio::FastqSeq curr_seq;
    htio::EncodedSeq curr_enc;
    htio::KmerList curr_kmer;
    vector<int16_t> curr_qual;

    int64_t n_accept = 0;
    int64_t n_seq = 0;

    const size_t num_left = primers_left.size();
    const size_t num_right = primers_right.size();

    for (size_t file_i = 0; file_i < OPT_files_in.size(); file_i++)
    {
        htio::FastqIO IN(OPT_files_in[file_i], htio::HTIO_READ, OPT_gzip);

        while (IN.next_seq(curr_seq))
        {
            htio::PosType read_start = 0;
            htio::PosType read_end = 0;
            htio::PosType primer_start = 0;
            htio::PosType primer_end = 0;

            bool left_ok = false;
            bool right_ok = false;
            htio::PosType trim_from = 0;
            htio::PosType trim_to = 0;

            // preprocess current read
            htio::encode_nt(curr_seq.seq, curr_enc);
            htio::gen_kmer_nt(curr_enc, curr_kmer, kmer_size);
            htio::decode_quality(curr_seq.quality, curr_qual, OPT_encode);

            //
            // compare with primers
            //

            // left primer
            for (size_t i = 0; i < num_left; i++)
            {
                const size_t curr_primer_len = primers_left[i].length();
                bool aligned = align_primer(curr_seq.seq, curr_qual, curr_kmer,
                                            primers_left[i], primers_left_klist[i], primers_left_kpos[i],
                                            read_start, read_end, primer_start, primer_end);
                if (aligned && LEFT_START_OK && LEFT_END_OK)
                {
                    left_ok = true;
                    trim_from = read_end + 1;
                    break;
                }
            }

            // right primer revcom
            for (size_t i = 0; i < num_right; i++)
            {
                const size_t curr_primer_len = primers_right_rev[i].length();
                bool aligned = align_primer(curr_seq.seq, curr_qual, curr_kmer,
                                            primers_right_rev[i], primers_right_rev_klist[i], primers_right_rev_kpos[i],
                                            read_start, read_end, primer_start, primer_end);
                if (aligned && RIGHT_START_OK && RIGHT_END_OK)
                {
                    right_ok = true;
                    trim_to = read_start - 1;
                    break;
                }
            }

            // compare with reverse complement strand
            if (OPT_check_revcom)
            {
                // right primer
                if (!right_ok)
                {
                    for (size_t i = 0; i < num_right; i++)
                    {
                        const size_t curr_primer_len = primers_right[i].length();
                        bool aligned = align_primer(curr_seq.seq, curr_qual, curr_kmer,
                                                    primers_right[i], primers_right_klist[i], primers_right_kpos[i],
                                                    read_start, read_end, primer_start, primer_end);
                        // aligned on left, using left rules
                        if (aligned && LEFT_START_OK && LEFT_END_OK)
                        {
                            right_ok = true;
                            trim_from = read_end + 1;
                            break;
                        }
                    }
                }

                // left primer revcom
                if (!left_ok)
                {
                    for (size_t i = 0; i < num_left; i++)
                    {
                        const size_t curr_primer_len = primers_left_rev[i].length();
                        bool aligned = align_primer(curr_seq.seq, curr_qual, curr_kmer,
                                                    primers_left_rev[i], primers_left_rev_klist[i], primers_left_rev_kpos[i],
                                                    read_start, read_end, primer_start, primer_end);
                        // aligned on right, using right rules
                        if (aligned && RIGHT_START_OK && RIGHT_END_OK)
                        {
                            left_ok = true;
                            trim_to = read_start - 1;
                            break;
                        }
                    }
                }
            }

            // write output
            n_seq++;
            if ((!num_left || left_ok) &&
                (!num_right || right_ok))
            {
                n_accept++;
                htio::FastqSeq trimmed_seq;
                curr_seq.subseq(trimmed_seq, trim_from, trim_to - trim_from + 1);
                OUT.write_seq(trimmed_seq);
            }
            else if (OPT_prefix_fail.length())
                FAIL->write_seq(curr_seq);

            if (!OPT_quiet && n_seq % LOG_BLOCK == 0)
                cout << "  " << n_seq << " reads, " << n_accept << " trimmed" << endl;
        }
    }

    if (FAIL) delete FAIL;

    if (!OPT_quiet)
        cout << "  " << n_seq << " reads, " << n_accept << " trimmed" << endl;
}

void trim_pe()
{
    vector<string> files_in_a;
    vector<string> files_in_b;
    separate_paired_files(OPT_files_in, files_in_a, files_in_b);

    string file_out_a = OPT_prefix_out + "_1.fastq";
    string file_out_b = OPT_prefix_out + "_2.fastq";
    if (OPT_gzip)
    {
        file_out_a += ".gz";
        file_out_b += ".gz";
    }

    string file_fail_a;
    string file_fail_b;
    if (OPT_prefix_fail.length())
    {
        file_fail_a = OPT_prefix_fail + "_1.fastq";
        file_fail_b = OPT_prefix_fail + "_2.fastq";
        if (OPT_gzip)
        {
            file_fail_a += ".gz";
            file_fail_b += ".gz";
        }
    }

    // check if output file is same with any input file
    for (size_t i = 0; i < OPT_files_in.size(); i++)
    {
        if (OPT_files_in[i] == file_out_a ||
            OPT_files_in[i] == file_out_b ||
            (OPT_prefix_fail.length() &&
             (OPT_files_in[i] == file_fail_a ||
              OPT_files_in[i] == file_fail_b)
             )
            )
        {
            cerr << "output file will overwrite input file: " << OPT_files_in[i] << endl;
            exit(EXIT_FAILURE);
        }
    }

    htio::FastqIO OUT_A(file_out_a, htio::HTIO_WRITE, OPT_gzip);
    htio::FastqIO OUT_B(file_out_b, htio::HTIO_WRITE, OPT_gzip);

    htio::FastqIO* FAIL_A = NULL;
    htio::FastqIO* FAIL_B = NULL;
    if (OPT_prefix_fail.length())
    {
        FAIL_A = new htio::FastqIO(file_fail_a, htio::HTIO_WRITE, OPT_gzip);
        FAIL_B = new htio::FastqIO(file_fail_b, htio::HTIO_WRITE, OPT_gzip);
    }

    const size_t num_left = primers_left.size();
    const size_t num_right = primers_right.size();

    size_t n_seq = 0;
    size_t n_accept = 0;

    htio::FastqSeq curr_seq_a;
    htio::FastqSeq curr_seq_b;
    htio::EncodedSeq curr_enc_a;
    htio::EncodedSeq curr_enc_b;
    htio::KmerList curr_kmer_a;
    htio::KmerList curr_kmer_b;
    vector<int16_t> curr_qual_a;
    vector<int16_t> curr_qual_b;

    for (size_t file_i = 0; file_i < files_in_a.size(); file_i++)
    {
        htio::FastqIO IN_A(files_in_a[file_i], htio::HTIO_READ, OPT_gzip);
        htio::FastqIO IN_B(files_in_b[file_i], htio::HTIO_READ, OPT_gzip);

        while (1)
        {
            bool re_a = IN_A.next_seq(curr_seq_a);
            bool re_b = IN_B.next_seq(curr_seq_b);

            if (re_a)
            {
                if (re_b);
                else
                {
                    cerr << "input file B finished, but input file A not" << endl
                        << files_in_a[file_i] << " and " << files_in_b[file_i] << endl;
                    exit(EXIT_FAILURE);
                }
            }
            else
            {
                if (re_b)
                {
                    cerr << "input file A finished, but input file B not" << endl
                        << files_in_a[file_i] << " and " << files_in_b[file_i] << endl;
                    exit(EXIT_FAILURE);
                }
                else
                    break;
            }

            htio::PosType read_start = 0;
            htio::PosType read_end = 0;
            htio::PosType primer_start = 0;
            htio::PosType primer_end = 0;

            bool left_ok = false;
            bool right_ok = false;
            htio::PosType trim_r1 = 0;
            htio::PosType trim_r2 = 0;

            // preprocess current read
            htio::encode_nt(curr_seq_a.seq, curr_enc_a);
            htio::encode_nt(curr_seq_b.seq, curr_enc_b);
            htio::gen_kmer_nt(curr_enc_a, curr_kmer_a, kmer_size);
            htio::gen_kmer_nt(curr_enc_b, curr_kmer_b, kmer_size);
            htio::decode_quality(curr_seq_a.quality, curr_qual_a, OPT_encode);
            htio::decode_quality(curr_seq_b.quality, curr_qual_b, OPT_encode);

            //
            // compare with primers
            //

            // left
            for (size_t i = 0; i < num_left; i++)
            {
                const size_t curr_primer_len = primers_left[i].length();
                bool aligned = align_primer(curr_seq_a.seq, curr_qual_a, curr_kmer_a,
                                            primers_left[i], primers_left_klist[i], primers_left_kpos[i],
                                            read_start, read_end, primer_start, primer_end);
                if (aligned && LEFT_START_OK && LEFT_END_OK)
                {
                    left_ok = true;
                    trim_r1 = read_end + 1;
                    break;
                }
            }

            // right
            for (size_t i = 0; i < num_right; i++)
            {
                const size_t curr_primer_len = primers_right[i].length();
                bool aligned = align_primer(curr_seq_b.seq, curr_qual_b, curr_kmer_b,
                                            primers_right[i], primers_right_klist[i], primers_right_kpos[i],
                                            read_start, read_end, primer_start, primer_end);
                if (aligned && LEFT_START_OK && LEFT_END_OK)
                {
                    right_ok = true;
                    trim_r2 = read_end + 1;
                    break;
                }
            }

            // revcom
            if (OPT_check_revcom)
            {
                // align right revcom on read 1
                if (!right_ok)
                {
                    for (size_t i = 0; i < num_right; i++)
                    {
                        const size_t curr_primer_len = primers_right_rev[i].length();
                        bool aligned = align_primer(curr_seq_a.seq, curr_qual_a, curr_kmer_a,
                                                    primers_right_rev[i], primers_right_rev_klist[i], primers_right_rev_kpos[i],
                                                    read_start, read_end, primer_start, primer_end);
                        if (aligned && LEFT_START_OK && LEFT_END_OK)
                        {
                            right_ok = true;
                            trim_r1 = read_end + 1;
                            break;
                        }
                    }
                }

                // align left revcom on read 2
                if (!left_ok)
                {
                    for (size_t i = 0; i < num_left; i++)
                    {
                        const size_t curr_primer_len = primers_left_rev[i].length();
                        bool aligned = align_primer(curr_seq_b.seq, curr_qual_b, curr_kmer_b,
                                                    primers_left_rev[i], primers_left_rev_klist[i], primers_left_rev_kpos[i],
                                                    read_start, read_end, primer_start, primer_end);
                        if (aligned && LEFT_START_OK && LEFT_END_OK)
                        {
                            left_ok = true;
                            trim_r2 = read_end + 1;
                            break;
                        }
                    }
                }
            }

            // write output
            n_seq++;
            if ((!num_left || left_ok) && (!num_right || right_ok))
            {
                n_accept++;
                htio::FastqSeq trimmed_a;
                htio::FastqSeq trimmed_b;
                curr_seq_a.subseq(trimmed_a, trim_r1);
                curr_seq_b.subseq(trimmed_b, trim_r2);
                OUT_A.write_seq(trimmed_a);
                OUT_B.write_seq(trimmed_b);
            }
            else if (OPT_prefix_fail.length())
            {
                FAIL_A->write_seq(curr_seq_a);
                FAIL_B->write_seq(curr_seq_b);
            }

            if (!OPT_quiet && n_seq % LOG_BLOCK == 0)
                cout << "  " << n_seq << " pairs, " << n_accept << " trimmed" << endl;
        }
    }

    if (FAIL_A) delete FAIL_A;
    if (FAIL_B) delete FAIL_B;

    if (!OPT_quiet)
        cout << "  " << n_seq << " pairs, " << n_accept << " trimmed" << endl;
}

int main(int argc, char** argv)
{
    parse_options(argc, argv);
    if (!OPT_quiet) log_header();

    read_primers();

    if (OPT_paired)
        trim_pe();
    else if (OPT_single)
        trim_se();
    else
    {
        cerr << "neither single nor paired" << endl;
        exit(EXIT_FAILURE);
    }
    if (!OPT_quiet)
        cout << "done" << endl;
}