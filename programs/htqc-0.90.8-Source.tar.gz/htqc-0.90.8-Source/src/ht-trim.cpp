//     HTQC - a high-throughput sequencing quality control toolkit
//
//     This program is free software: you can redistribute it and/or modify
//     it under the terms of the GNU General Public License as published by
//     the Free Software Foundation, either version 3 of the License, or
//     (at your option) any later version.
//
//     This program is distributed in the hope that it will be useful,
//     but WITHOUT ANY WARRANTY; without even the implied warranty of
//     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//     GNU General Public License for more details.
//
//     You should have received a copy of the GNU General Public License
//     along with this program.  If not, see <http://www.gnu.org/licenses/>.

#include "htio1/FastqIO.h"
#include "htio1/FastqSeq.h"

#define USE_file_out
#define USE_encode
#define USE_single_paired
#include "htqc/Options.h"
#include "htio1/QualityUtil.h"

using namespace std;
using namespace htqc;
using namespace htio;

//
// type definitions
//

enum TrimSide
{
    TRIM_FROM_HEAD = 1,
    TRIM_FROM_TAIL = 1 << 1
};

string trim_side_to_string(TrimSide side)
{
    if (side == TRIM_FROM_HEAD)
    {
        return "head";
    }
    else if (side == TRIM_FROM_TAIL)
    {
        return "tail";
    }
    else if (side == (TRIM_FROM_HEAD | TRIM_FROM_TAIL))
    {
        return "both";
    }
    else
    {
        cerr << "invalid side enum value: " << int(side) << endl;
        exit(EXIT_FAILURE);
    }
}

//
// command line options
//
#define DEFAULT_KMER_SIZE 5
#define DEFAULT_QUAL_CUT 20

unsigned char OPT_trim_side = TRIM_FROM_HEAD | TRIM_FROM_TAIL;
string OPT_trim_side_STR;
size_t OPT_word_size;
int OPT_qual_cut;

//
// subs
//

void parse_options(int argc, char** argv)
{
    opt::options_description group_main("Options");
    group_main.add_options()
    OPT_files_in_ENTRY
    OPT_file_out_ENTRY
        ("trim-side,S", opt::value<string > (&OPT_trim_side_STR)->default_value("both"), "Trim is performed on which side: head|tail|both.")
        ("cut-quality,C", opt::value<int>(&OPT_qual_cut)->default_value(20), "Quality cutoff.")
        ("word-size,W", opt::value<size_t>(&OPT_word_size)->default_value(5), "Number of continuous high quality bases.");

    opt::options_description group_misc("Misc options:");
    group_misc.add_options()
    OPT_encode_ENTRY
    OPT_gzip_ENTRY
    OPT_quiet_ENTRY
    OPT_help_ENTRY
    OPT_version_ENTRY;
    group_main.add(group_misc);

    opt::variables_map var_map;
    opt::store(opt::parse_command_line(argc, argv, group_main), var_map);
    opt::notify(var_map);

    // we are always processing single-end
    OPT_single = true;

    //
    // show help
    //
    if (OPT_help)
    {
        cout << endl
            << argv[0] << " - remove bad bases from reads head or tail"
            << endl << endl
            << group_main;
        exit(EXIT_SUCCESS);
    }

    if (OPT_version) show_version_and_exit();

    //
    // validate options
    //
    if (OPT_file_out.length() == 0)
    {
        cerr << "output file not specified" << endl;
        exit(EXIT_FAILURE);
    }

    if (OPT_word_size < 1 || OPT_word_size > 16)
    {
        cerr << "invalid kmer size: " << OPT_word_size << ", must between 1 - 16" << endl;
        exit(EXIT_FAILURE);
    }

    if (OPT_trim_side_STR == "head")
        OPT_trim_side = TRIM_FROM_HEAD;
    else if (OPT_trim_side_STR == "tail")
        OPT_trim_side = TRIM_FROM_TAIL;
    else if (OPT_trim_side_STR == "both")
        OPT_trim_side = TRIM_FROM_HEAD | TRIM_FROM_TAIL;
    else
    {
        cerr << "invalid trim side: " << OPT_trim_side_STR << ", must be head|tail|both" << endl;
        exit(EXIT_FAILURE);
    }

    //
    // guess quality encoding
    //
    if (OPT_encode == HTIO_ENCODE_AUTO)
    {
        if (!OPT_quiet) cout << "guess encode from front " << NUM_GUESS << " sequences of file " << OPT_files_in[0] << endl;
        FastqIO fh(OPT_files_in[0], HTIO_READ, OPT_gzip);
        OPT_encode = guess_quality_encode(fh, NUM_GUESS);
        if (OPT_encode == HTIO_ENCODE_UNKNOWN || OPT_encode == HTIO_ENCODE_AUTO)
        {
            cerr << "failed to guess quality encode from input file " << OPT_files_in[0] << endl;
            exit(EXIT_FAILURE);
        }
        if (!OPT_quiet) cout << "encode: " << encode_to_string(OPT_encode) << endl;
    }
}


//
// main
//

string to_str(uint16_t kmer)
{
    string re;
    for (size_t i = 0; i < OPT_word_size; i++)
    {
        if (kmer & (1 << i))
            re.push_back('1');
        else
            re.push_back('0');
    }
    return re;
}

int main(int argc, char **argv)
{
    // parse arguments
    parse_options(argc, argv);

    // output
    if (OPT_gzip && OPT_file_out.rfind(".gz") == string::npos)
    {
        OPT_file_out += ".gz";
    }

    FastqIO OUT(OPT_file_out, HTIO_WRITE, OPT_gzip);

    // show parameters
    if (!OPT_quiet)
    {
        show_files_in();
        show_file_out();
        cout << "# trim side: " << OPT_trim_side_STR << endl;
        cout << "# word size: " << OPT_word_size << endl;
        cout << "# quality cutoff: " << OPT_qual_cut << endl;
    }

    // generate kmer that is perfect
    uint16_t perfect = 0;
    for (size_t i = 0; i < OPT_word_size; i++)
        perfect |= 1 << i;

    //
    // traverse input
    //
    size_t n = 0;
    FastqSeq curr_seq;
    FastqSeq curr_seq_sub;
    for (size_t file_i = 0; file_i < OPT_files_in.size(); file_i++)
    {
        FastqIO IN(OPT_files_in[file_i], HTIO_READ, OPT_gzip);

        while (IN.next_seq(curr_seq))
        {
            n++;

            ssize_t len = curr_seq.length();
            ssize_t i_start = 0;
            ssize_t i_end = len - 1;

            // sequence must be long enough
            if (len < OPT_word_size * 2)
            {
                i_end = i_start - 1;
                goto TRIM_DONE;
            }

            // trim from head
            if (OPT_trim_side & TRIM_FROM_HEAD)
            {
                // the first kmer
                uint16_t kmer = 0;
                for (size_t i = 0; i < OPT_word_size; i++)
                {
                    int32_t qual = decode_quality(curr_seq.quality[i], OPT_encode);
                    bool curr_ok = (OPT_qual_cut <= qual);
                    kmer |= curr_ok << i;
                }

                // traverse all remaining kmers
                if (kmer != perfect)
                {
                    while (true)
                    {
                        if (i_start == len - OPT_word_size) break;
                        i_start++;

                        int32_t qual = decode_quality(curr_seq.quality[i_start + OPT_word_size - 1], OPT_encode);
                        bool curr_ok = (OPT_qual_cut <= qual);
                        kmer >>= 1;
                        kmer |= curr_ok << (OPT_word_size - 1);
                        kmer &= perfect;
                        if (kmer == perfect) break;
                    }
                }
            }

            // trim from tail
            if (OPT_trim_side & TRIM_FROM_TAIL)
            {
                // the last kmer
                uint16_t kmer = 0;
                for (size_t i = 0; i < OPT_word_size; i++)
                {
                    int32_t qual = decode_quality(curr_seq.quality[len - OPT_word_size + i], OPT_encode);
                    bool curr_ok = (OPT_qual_cut <= qual);
                    kmer |= curr_ok << i;
                }

                // traverse all remaining kmers
                if (kmer != perfect)
                {
                    while (true)
                    {
                        if (i_end == i_start - 1) break;
                        i_end--;
                        int qual = decode_quality(curr_seq.quality[i_end - OPT_word_size + 1], OPT_encode);
                        bool curr_ok = (OPT_qual_cut <= qual);
                        kmer <<= 1;
                        kmer |= curr_ok;
                        kmer &= perfect;
                        if (kmer == perfect) break;
                    }
                }
            }

            // write output
TRIM_DONE:
            int trim_len = i_end - i_start + 1;
            curr_seq.subseq(curr_seq_sub, i_start, trim_len);
            OUT.write_seq(curr_seq_sub);

            if (!OPT_quiet && (n % LOG_BLOCK == 0))
                cout << "\t" << n << " reads" << endl;
        }
    }

    if (!OPT_quiet)
        cout << "done: " << n << " reads" << endl;

}