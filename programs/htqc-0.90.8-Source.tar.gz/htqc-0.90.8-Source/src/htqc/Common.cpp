//     HTQC - a high-throughput sequencing quality control toolkit
//
//     This program is free software: you can redistribute it and/or modify
//     it under the terms of the GNU General Public License as published by
//     the Free Software Foundation, either version 3 of the License, or
//     (at your option) any later version.
//
//     This program is distributed in the hope that it will be useful,
//     but WITHOUT ANY WARRANTY; without even the implied warranty of
//     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//     GNU General Public License for more details.
//
//     You should have received a copy of the GNU General Public License
//     along with this program.  If not, see <http://www.gnu.org/licenses/>.
#include "htqc/Common.h"

using namespace std;
using namespace htio;

namespace htqc
{
const int LOG_BLOCK = 50000;
const size_t NUM_GUESS = 500;

std::string encode_to_string(QualityEncode encode)
{
    switch (encode)
    {
    case HTIO_ENCODE_SANGER:
        return "sanger";
    case HTIO_ENCODE_CASAVA_1_8:
        return "casava1.8";
    case HTIO_ENCODE_SOLEXA:
        return "solexa";
    case HTIO_ENCODE_ILLUMINA:
        return "illumina";
    default:
        throw runtime_error("cannot format invalid encode value to string");
    }
}

std::string bool_to_string(bool value)
{
    return value ? "T" : "F";
}

std::string header_format_to_string(HeaderFormat format)
{
    switch (format)
    {
    case HTIO_HEADER_PRI_1_8:
        return "pri_casava1.8";
    case HTIO_HEADER_1_8:
        return "casava1.8";
    default:
        throw runtime_error("cannot format invalid header format value to string");
    }
}

}






