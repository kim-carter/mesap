#include "htio1/FastqIO.h"
#include "htio1/FastqSeq.h"
#include <stdio.h>

using namespace std;
using namespace htio;

int main(int argc, char** argv)
{
    FastqIO IN(stdin, false);
    FastqIO OUT(stdout, false);
    FastqSeq curr_seq;

    size_t num_seq = 0;
    while (IN.next_seq(curr_seq))
    {
        num_seq++;
        if (num_seq % 10000 == 0) cout << num_seq << " read and write" << endl;
        OUT.write_seq(curr_seq);

    }
}
