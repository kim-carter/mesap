#include "htio1/SeqIO.h"
#include "htio1/GzipFileHandle.h"
#include "htio1/PlainFileHandle.h"
#include "htio1/FastqIO.h"
#include "htio1/FastaIO.h"
#include <zlib.h>

using namespace std;

namespace htio
{

inline const char* get_io_mode_str(IOMode mode)
{
    switch (mode)
    {
    case HTIO_READ:
        return "rb";
    case HTIO_WRITE:
        return "wb";
    case HTIO_APPEND:
        return "ab";
    default:
        throw runtime_error("invalid IO mode");
    }
}

SeqIO::SeqIO(const std::string& file, IOMode mode, bool gzipped)
{
    const char* mode_str = get_io_mode_str(mode);

    if (gzipped)
        handle = new GzipFileHandle(file.c_str(), mode_str);
    else
        handle = new PlainFileHandle(file.c_str(), mode_str);
}

SeqIO::SeqIO(FileHandle* handle)
: handle(handle)
{
}

SeqIO::SeqIO(FILE* handle, bool auto_close)
: handle(new PlainFileHandle(handle, auto_close))
{
}

SeqIO::SeqIO(gzFile handle, bool auto_close)
: handle(new GzipFileHandle(handle, auto_close))
{
}

typedef enum
{
    HTIO_FASTA = 0,
    HTIO_FASTQ = 1,
} SeqFileFormat;

SeqFileFormat guess_seq_file_format(FileHandle* handle)
{
    // go to file begin
    off_t pos = handle->tell();
    handle->seek(0, 0);

    // read first line, guess format
    string line;
    handle->read_line(line);

    SeqFileFormat format;
    if (line[0] == '>')
        format = HTIO_FASTA;
    else if (line[0] == '@')
        format = HTIO_FASTQ;
    else
        throw runtime_error("failed to guess sequence format from content:\n" + line);

    // restore file position
    handle->seek(pos, 0);

    return format;
}

SeqIO* SeqIO::New(const std::string& file, IOMode mode, bool gzipped)
{
    FileHandle* handle = NULL;
    if (gzipped)
        handle = new GzipFileHandle(file.c_str(), get_io_mode_str(mode));
    else
        handle = new PlainFileHandle(file.c_str(), get_io_mode_str(mode));

    return SeqIO::New(handle);
}

SeqIO* SeqIO::New(FileHandle* handle)
{
    SeqIO* seq_handle = NULL;
    SeqFileFormat format = guess_seq_file_format(handle);
    switch (format)
    {
    case HTIO_FASTA:
        seq_handle = new FastaIO(handle);
        break;
    case HTIO_FASTQ:
        seq_handle = new FastqIO(handle);
        break;
    default:
        throw runtime_error("file format neither FASTA nor FASTQ");
    }
    return seq_handle;
}

SeqIO* SeqIO::New(FILE* handle, bool auto_close)
{
    return SeqIO::New(new PlainFileHandle(handle, auto_close));
}

SeqIO* SeqIO::New(gzFile handle, bool auto_close)
{
    return SeqIO::New(new GzipFileHandle(handle, auto_close));
}

SeqIO::~SeqIO()
{
    delete handle;
}

void SeqIO::seek(off_t offset, int whence)
{
    handle->seek(offset, whence);
}

off_t SeqIO::tell() const
{
    return handle->tell();
}

} // namespace htio
