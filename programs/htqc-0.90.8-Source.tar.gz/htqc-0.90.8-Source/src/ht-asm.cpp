//     HTQC - a high-throughput sequencing quality control toolkit
//
//     This program is free software: you can redistribute it and/or modify
//     it under the terms of the GNU General Public License as published by
//     the Free Software Foundation, either version 3 of the License, or
//     (at your option) any later version.
//
//     This program is distributed in the hope that it will be useful,
//     but WITHOUT ANY WARRANTY; without even the implied warranty of
//     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//     GNU General Public License for more details.
//
//     You should have received a copy of the GNU General Public License
//     along with this program.  If not, see <http://www.gnu.org/licenses/>.


#include "htio1/FastqIO.h"
#include "htio1/QualityUtil.h"

#define USE_file_out
#define USE_encode
#define USE_single_paired
#include "htqc/Options.h"
#include "htqc/MicroAssembler.h"

using namespace std;
using namespace htqc;
using namespace htio;

int OPT_word_size;
int OPT_conf_qual;
int OPT_iden;
int OPT_qual_diff;
string OPT_unjoin_prefix;

void parse_option(int argc, char** argv)
{
    opt::options_description group_main("Options:");
    group_main.add_options()
    OPT_files_in_ENTRY
    OPT_file_out_ENTRY
        ("out-non-asm,u", opt::value<string > (&OPT_unjoin_prefix), "write non-assembled reads to PREFIX_[12].fastq");

    opt::options_description group_asm("Assembly options:");
    group_asm.add_options()
        ("kmer-size", opt::value<int>(&OPT_word_size)->default_value(7), "Assembly begins from identical kmers of this size.")
        ("cut-qual", opt::value<int>(&OPT_conf_qual)->default_value(20), "Matched bases must be better than this; and bases in kmer must be better than this.")
        ("cut-iden", opt::value<int>(&OPT_iden)->default_value(10), "Number of matches required for assembly.")
        ("cut-qual-diff", opt::value<int>(&OPT_qual_diff)->default_value(15), "Quality difference to accept mismatches.");
    group_main.add(group_asm);

    opt::options_description group_misc("Misc options:");
    group_misc.add_options()
    OPT_encode_ENTRY
    OPT_gzip_ENTRY
    OPT_quiet_ENTRY
    OPT_help_ENTRY
    OPT_version_ENTRY;
    group_main.add(group_misc);

    opt::variables_map var_map;
    opt::store(opt::parse_command_line(argc, argv, group_main), var_map);
    opt::notify(var_map);

    // we are always processing paired-end
    OPT_paired = true;

    //
    // show help
    //
    if (OPT_help)
    {
        cout << endl
            << argv[0] << " - assemble paired-ends into single sequences"
            << endl << endl
            << group_main;
        exit(EXIT_SUCCESS);
    }
    if (OPT_version) show_version_and_exit();

    // validate options
    if (OPT_file_out.length() == 0)
    {
        cerr << "output file not specified" << endl;
        exit(EXIT_FAILURE);
    }

    if (OPT_gzip)
    {
        if (OPT_file_out.rfind(".gz") == string::npos) OPT_file_out += ".gz";
    }

    tidy_prefix_out(OPT_unjoin_prefix);

    for (size_t i = 0; i < OPT_files_in.size(); i++)
    {
        if (OPT_files_in[i] == OPT_file_out)
        {
            cerr << "output file same with input file: " << OPT_file_out << endl;
            exit(EXIT_FAILURE);
        }
    }

    //
    // guess quality encoding
    //
    if (OPT_encode == HTIO_ENCODE_AUTO)
    {
        if (!OPT_quiet) cout << "guess quality encode from front " << NUM_GUESS << " sequences of file " << OPT_files_in[0] << endl;
        FastqIO fh(OPT_files_in[0], HTIO_READ, OPT_gzip);
        OPT_encode = guess_quality_encode(fh, NUM_GUESS);
        if (OPT_encode == HTIO_ENCODE_UNKNOWN || OPT_encode == HTIO_ENCODE_AUTO)
        {
            cerr << "failed to guess quality encode from input file " << OPT_files_in[0] << endl;
            exit(EXIT_FAILURE);
        }
        if (!OPT_quiet) cout << "quality encode is " << cast<string>(OPT_encode) << endl;
    }
}

int main(int argc, char** argv)
{
    parse_option(argc, argv);

    // input files
    vector<string> files_in_a;
    vector<string> files_in_b;
    separate_paired_files(OPT_files_in, files_in_a, files_in_b);

    // output
    FastqIO out(OPT_file_out, HTIO_WRITE, OPT_gzip);

    FastqIO* U1 = NULL;
    FastqIO* U2 = NULL;

    if (OPT_unjoin_prefix.length() != 0)
    {
        string file_u1 = string(OPT_unjoin_prefix) + "_1.fastq";
        string file_u2 = string(OPT_unjoin_prefix) + "_2.fastq";
        if (OPT_gzip)
        {
            file_u1 += ".gz";
            file_u2 += ".gz";
        }
        U1 = new FastqIO(file_u1, HTIO_WRITE, OPT_gzip);
        U2 = new FastqIO(file_u2, HTIO_WRITE, OPT_gzip);
    }

    // print options
    if (!OPT_quiet)
    {
        show_files_in();
        show_file_out();
        if (OPT_unjoin_prefix.length())
            cout << "# file prefix for non-assembled reads: " << OPT_unjoin_prefix << endl;
        show_encode();
        cout << "# assembly parameters:" << endl;
        cout << "#   kmer size: " << OPT_word_size << endl;
        cout << "#   quality for confidental bases: " << OPT_conf_qual << endl;
        cout << "#   quality difference for acceptable conflict bases: " << OPT_qual_diff << endl;
        cout << "#   required number of identical bases: " << OPT_iden << endl;
    }

    // traverse input
    size_t n_seq = 0;
    size_t n_asm = 0;
    FastqSeq curr_a;
    FastqSeq curr_b;
    FastqSeq curr_b_revcom;
    MicroAssembler assembler(OPT_encode,
                             OPT_word_size,
                             OPT_conf_qual,
                             OPT_iden,
                             OPT_qual_diff
                             );

    if (!OPT_quiet)
        cout << "beginning assembly" << endl;

    for (size_t file_i = 0; file_i < files_in_a.size(); file_i++)
    {
        FastqIO parser_a(files_in_a[file_i], HTIO_READ, OPT_gzip);
        FastqIO parser_b(files_in_b[file_i], HTIO_READ, OPT_gzip);
        while (1)
        {
            bool re_a = parser_a.next_seq(curr_a);
            bool re_b = parser_b.next_seq(curr_b);

            if (re_a)
            {
                if (re_b)
                {
                    curr_b.revcom(curr_b_revcom);
                    bool re = assembler.assemble(curr_a, curr_b_revcom);

                    if (re)
                    {
                        out.write_seq(assembler.result);
                        n_asm++;
                    }
                    else if (U1 && U2)
                    {
                        U1->write_seq(curr_a);
                        U2->write_seq(curr_b);
                    }

                    n_seq++;
                    if (!OPT_quiet && n_seq % LOG_BLOCK == 0)
                        cout << "  " << n_seq << " pairs, " << n_asm << " assembled" << endl;
                }
                else
                {
                    cerr << "input file B finished, but input file A not" << endl
                        << files_in_a[file_i] << " and " << files_in_b[file_i] << endl;
                    exit(EXIT_FAILURE);
                }
            }
            else
            {
                if (re_b)
                {
                    cerr << "input file A finished, but input file B not" << endl
                        << files_in_a[file_i] << " and " << files_in_b[file_i] << endl;
                    exit(EXIT_FAILURE);
                }
                else
                    break;
            }
        }
    }

    if (U1 && U2)
    {
        delete U1;
        delete U2;
    }

    if (!OPT_quiet)
    {
        cout << "  " << n_seq << " pairs, " << n_asm << " assembled" << endl;
        cout << "done" << endl;
    }
}