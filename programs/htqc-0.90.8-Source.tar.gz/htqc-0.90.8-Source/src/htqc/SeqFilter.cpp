#include <set>
#include "htio1/QualityUtil.h"
#include "htio1/HeaderUtil.h"
#include "htqc/SeqFilter.h"

namespace htqc
{

SeqFilter::~SeqFilter()
{
}

SeqFilterLength::SeqFilterLength(size_t cut_len, htio::QualityEncode encode, bool mask) :
encode(encode),
cut_len(cut_len),
mask(mask)
{
}

SeqFilterLength::~SeqFilterLength()
{
}

bool SeqFilterLength::check(const htio::FastqSeq& seq)
{
    if (mask)
    {
        size_t seq_len = seq.length();
        size_t valid_len = 0;
        for (size_t i = 0; i < seq_len; i++)
        {
            int qual = htio::decode_quality(seq.quality[i], encode);
            if (qual > 2) valid_len++;
        }
        return valid_len >= cut_len;
    }
    else
        return seq.length() >= cut_len;
}

SeqFilterQuality::SeqFilterQuality(int cut_qual, htio::QualityEncode encode, bool mask) :
cut_qual(cut_qual),
encode(encode),
mask(mask)
{
}

SeqFilterQuality::~SeqFilterQuality()
{
}

bool SeqFilterQuality::check(const htio::FastqSeq& seq)
{
    int64_t qual_summ = 0;
    size_t seq_len = seq.length();

    for (size_t i = 0; i < seq_len; i++)
    {
        int qual = htio::decode_quality(seq.quality[i], encode);
        if (!mask || qual > 2) qual_summ += qual;
    }

    return (qual_summ > 0 && qual_summ >= cut_qual * seq_len);
}

SeqFilterTile::SeqFilterTile(htio::HeaderFormat h_format, bool with_sra) :
h_parser(h_format, with_sra)
{
}

SeqFilterTile::~SeqFilterTile()
{
}

bool SeqFilterTile::check(const htio::FastqSeq& seq)
{
    h_parser.parse(seq.id, seq.desc);
    RejTileMap::iterator re = rej_tiles.find(h_parser.tile);
    if (re == rej_tiles.end())
    {
        return true;
    }
    else
    {
        re->second++;
        return false;
    }
}



} // namespace htqc
