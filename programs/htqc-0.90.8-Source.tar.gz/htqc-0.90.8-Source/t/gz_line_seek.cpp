#include <iostream>
#include "htio1/GzipFileHandle.h"

using namespace std;
using namespace htio;

int main(int argc, char** argv)
{
    if (argc != 2)
    {
        cerr << "usage: ./gz_line_seek gzipped_input_file" << endl;
        exit(EXIT_FAILURE);
    }

    GzipFileHandle IN(argv[1], "rb");

    off_t off_first = IN.tell();
    off_t off_last = -1;

    string line;
    while (1)
    {
        off_t curr_off = IN.tell();
        if (!IN.read_line(line)) break;
        off_last = curr_off;

        cout << "offset before: " << curr_off << endl;
        cout << "\"" << line << "\"" << endl;
        cout << "offset after: " << IN.tell() << endl;
        cout << endl;
    }

    cout << "# go to first line at " << off_first << endl;
    IN.seek(off_first, 0);
    IN.read_line(line);
    cout << "\"" << line << "\"" << endl;
    cout << endl;

    cout << "# go to last line at " << off_last << endl;
    IN.seek(off_last, 0);
    IN.read_line(line);
    cout << "\"" << line << "\"" << endl;
    cout << endl;
}
