#ifndef HTIO_KMER_H
#define	HTIO_KMER_H

#include "htio1/Common.h"
#include <boost/unordered_map.hpp>

namespace htio
{

typedef int8_t EncodedType;
typedef std::vector<EncodedType> EncodedSeq;

typedef uint64_t KmerType;
typedef std::vector<KmerType> KmerList;

typedef int32_t PosType;
typedef boost::unordered_multimap<KmerType, PosType> KmerPosMap;

/**
 * map ATGCN to numbers 0-4
 * @param input a nucleotide residue in ATGCN
 * @return numbers from 0 to 4
 */
inline EncodedType encode_nt(char input)
{
    switch (input)
    {
    case 'A':
    case 'a':
        return 0;
    case 'T':
    case 't':
        return 4;
    case 'G':
    case 'g':
        return 1;
    case 'C':
    case 'c':
        return 3;
    case 'N':
    case 'n':
        return 2;
    default:
        return -1;
    }
}

/**
 * map amino acids residues to 0-25.
 * @param input a amino acids residue
 * @return numbers from 0 to 25.
 */
inline EncodedType encode_aa(char input)
{
    if (input == '*') input = 'O';

    if ('a' <= input && input <= 'z') return input - 'a';
    else if ('A' <= input && input <= 'Z') return input - 'A';
    else return -1;
}

/**
 * Map encoded nucleotide residues back to characters. See encode_nt(char) for detail.
 * @param input residues in 0-4
 * @return residues in ATGCN.
 */
inline char decode_nt(EncodedType input)
{
    switch (input)
    {
    case 0:
        return 'A';
    case 4:
        return 'T';
    case 1:
        return 'G';
    case 3:
        return 'C';
    case 2:
        return 'N';
    case '-':
    case '.':
        return input;
    default:
        return -1;
    }
}

/**
 * Map encoded amino acids residues back to characters. See encode_aa(char) for detail.
 * @param input residues in 0-25
 * @return residues in characters.
 */
inline char decode_aa(EncodedType input)
{
    char result;
    if (0 <= input && input <= 25)
        result = input + 'A';
    else if (input == '-' || input == '.')
        result = input;
    else
        result = -1;

    if (result == 'O') result = '*';

    return result;
}

/**
 * Encode a string of nucleotides. See encode_nt(char) for detail.
 * @param seq
 * @param encoded_seq
 */
void encode_nt(const std::string& seq, EncodedSeq& encoded_seq);

/**
 * Encode a string of amino acids. See encode_aa(char) for detail.
 * @param seq
 * @param encoded_seq
 */
void encode_aa(const std::string& seq, EncodedSeq& encoded_seq);

/**
 * Decode a series of nucleotides. See decode_nt(EncodedType) for detail.
 * @param encoded_seq
 * @param seq
 */
void decode_nt(const EncodedSeq& encoded_seq, std::string& seq);

/**
 * Decode a series of amino acids. See decode_aa(EncodedType) for detail.
 * @param encoded_seq
 * @param seq
 */
void decode_aa(const EncodedSeq& encoded_seq, std::string& seq);

/**
 * reverse complement for encoded nucleotide sequence
 * @param from
 * @param to
 */
void revcom(const EncodedSeq& in, EncodedSeq& out);

/**
 * test whether two sequences are identical
 * @param a
 * @param b
 * @return 
 */
bool operator==(const EncodedSeq& a, const EncodedSeq& b);

/**
 * Generate a series of kmers along the length of nucleotide sequence.
 * Each kmer is considered to be a quinary number of k digits, and is stored in a 64 bit unsigned integer.
 * @param encoded_seq encoded nucleotide sequence
 * @param result series of generated kmers
 * @param kmer_size
 */
void gen_kmer_nt(const EncodedSeq& encoded_seq, KmerList& result, size_t kmer_size);

/**
 * generate one kmer from nucleotide sequence
 * @param seq sequence in string. String length is kmer size.
 * @return generated kmer
 */
KmerType gen_kmer_nt(const std::string& seq);

/**
 * Generate a series of kmers along the length of amino acids sequence.
 * Each kmer is considered to be a 26-nary number of k digits, and is stored in a 64 bit unsigned integer.
 * @param encoded_seq encoded amino acids sequence
 * @param result series of generated kmers
 * @param kmer_size
 */
void gen_kmer_aa(const EncodedSeq& encoded_seq, KmerList& result, size_t kmer_size);

/**
 * generate one kmer from amino acids sequence
 * @param seq sequence in string. String length is kmer size.
 * @return generated kmer
 */
KmerType gen_kmer_aa(const std::string& seq);

/**
 * test whether two series of kmers are identical
 * @param a
 * @param b
 * @return 
 */
bool operator==(const KmerList& a, const KmerList& b);

/**
 * position is 0-based
 * @param kmer_list series of kmers
 * @param kmer_pos a multimap with kmers as key.
 */
void summ_kmer_pos(const KmerList& kmer_list, KmerPosMap& kmer_pos);

/**
 * decode nucleotide kmer to human-readable string
 * @param kmer
 * @param kmer_size
 * @return 
 */
std::string decode_kmer_nt(KmerType kmer, size_t kmer_size);

/**
 * decode amino acids kmer to human-readable string
 * @param kmer
 * @param kmer_size
 * @return 
 */
std::string decode_kmer_aa(KmerType kmer, size_t kmer_size);

} // namespace htio

#endif	/* HTIO_KMER_H */

