#include "kslib.h"

#include <stdlib.h>
#include <stdio.h>
#include <sys/types.h>
#include <dirent.h>
#include <string.h>
#include <errno.h>
#include <getopt.h>
							      

					      

struct parameters{
	char* indir;
	char* outdir;
	int run;
	int help;
};


struct file_collector{
	char* id;
	char** read1;
	char** read2;
	int numread1;
	int numread2;
	struct file_collector* next;
};

char* FASTQMERGER = "0.1.0";
char* PACKAGE_BUGREPORT = "timo.lassmann@telethonkids.org.au";
char* PACKAGE_NAME = "mesap";
char* PACKAGE_STRING = "mesap 1.1.0";
char* PACKAGE_VERSION = "1.1.0";


#define OPT_INDIR 1
#define OPT_OUTDIR 2
#define OPT_RUN 3

#define MAXLANES 100
#define MAXFILENAME 1000

int read_files(struct parameters* param);
char* get_base_name(char*filename);
void print_files (struct file_collector* n);
void run_concatenate (struct file_collector* n,char* indir, char* outdir);
struct file_collector* insert (struct file_collector* n, char* id,char* name, int read);
void free_file_collector (struct file_collector* n);

int detect_paired_end(struct file_collector* n,int* pair);
int count_R1_R2(struct file_collector* n,int* R1,int*R2);


int cstring_cmp(const void *a, const void *b);

int main(int argc, char * argv[])
{
	struct parameters* param = 0;
	int c;
	int status;
	MMALLOC(param,sizeof(struct parameters));

	param->indir = 0;
	param->outdir = 0;
	param->run = 0;
	param->help = 0;
	
	while (1){
		static struct option long_options[] ={
			{"indir",required_argument,0,OPT_INDIR},
			{"outdir",required_argument,0,OPT_OUTDIR},
			{"run",0,0,OPT_RUN},
			
			{"help",0,0,'h'},
			{0, 0, 0, 0}
		};
		
		int option_index = 0;
		c = getopt_long_only (argc, argv,"h",long_options, &option_index);
		
		if (c == -1){
			break;
		}
		
		switch(c) {
			case 0:
				break;
			case OPT_INDIR:
				param->indir = optarg;
				break;
			case OPT_OUTDIR:
				param->outdir = optarg;
				break;
			case OPT_RUN:
				param->run = 1;
				break;
				
			case 'h':
				param->help = 1;
				break;
			case '?':
				exit(1);
				break;
			default:
				fprintf(stderr,"default\n\n\n\n");
				abort ();
		}
	}
	
	if(param->help || !param->indir  || !param->outdir ){
		fprintf(stdout, "\n%s %s, Copyright (C) 2013 Timo Lassmann <%s>\n",PACKAGE_NAME,PACKAGE_VERSION,PACKAGE_BUGREPORT);
		fprintf(stdout, "Program: fastqmerger %s\n\n",FASTQMERGER );
		fprintf(stdout, "\n");
		fprintf(stdout, "Usage:   fastqmerger --indir <> --outdir <> \n\n");
		MFREE(param);
		exit(EXIT_SUCCESS);
	}
	
	if((status = read_files(param)) != kslOK) KSLIB_XEXCEPTION(kslFAIL,"read_files failed.\n");
	
	
	MFREE(param);
	return EXIT_SUCCESS;
ERROR:
	return EXIT_FAILURE;
}
					      
int read_files(struct parameters* param)
{
	DIR * d;
	struct file_collector* root = NULL;
	d = opendir (param->indir);
	int status;
	char* tmp_name = NULL;
	
	if (! d) {
		fprintf (stderr, "Cannot open directory '%s': %s\n", param->indir, strerror (errno));
		exit (EXIT_FAILURE);
	}
	while (1) {
		struct dirent * entry;
		
		entry = readdir (d);
		if (! entry) {
			break;
		}
		
		if(strlen(entry->d_name)  > 11){
			
			if(!strcmp("R1.fastq.gz",entry->d_name + (strlen(entry->d_name) - 11))){
				//fprintf(stderr,"%s\n", entry->d_name);
				//fprintf(stderr,"%s\n",get_base_name(entry->d_name));
				tmp_name = NULL;
				if((tmp_name = get_base_name(entry->d_name)) == NULL ){
					
					fprintf(stderr,"WARNING: Could not obtain a sample name for file:%s!\n",entry->d_name);
				}else{
					
					
					
					root = insert(root, tmp_name, entry->d_name,0);
				}
			}
			
			if(!strcmp("R2.fastq.gz",entry->d_name + (strlen(entry->d_name) - 11))){
				//fprintf (stderr,"%s\n", entry->d_name);
				//fprintf(stderr,"%s\n",get_base_name(entry->d_name));
				tmp_name = NULL;
				if((tmp_name = get_base_name(entry->d_name)) == NULL ){
					
					fprintf(stderr,"WARNING: Could not obtain a sample name for file:%s!\n",entry->d_name);
				}else{
					root = insert(root, get_base_name(entry->d_name), entry->d_name,1);
				}
			}
		}
	}
	
	/* Close the directory. */
	if (closedir (d)) {
		fprintf (stderr, "Could not close '%s': %s\n",	 param->indir, strerror (errno));
		exit (EXIT_FAILURE);
	}

	

	int pair = 0;
	if((status = detect_paired_end(root,&pair)) != kslOK)KSLIB_XEXCEPTION(status,"detect_paired_end failed\n");
	
	
	if(pair == 1){
		fprintf(stdout,"The datasets are single end libraries.\n");
	}else if(pair == 2){
		fprintf(stdout,"The datasets are paired  end libraries.\n");
	}
	
	
	
	
	if(param->run){
		run_concatenate(root,param->indir,param->outdir);
	}else{
		if(root){
			print_files (root);
			fprintf(stdout, "\n******************************\n");
			fprintf(stdout, "If you are happy with merging the fastq files as indicated above run:\n\n");
			fprintf(stdout, "Usage:   fastqmerger -run --indir <> --outdir <> \n\n");
			fprintf(stdout, "******************************\n");
		}else{
			fprintf(stdout, "\n******************************\n");
			fprintf(stdout, "WARNING:Could not find files for merging.\n");
			fprintf(stdout, "******************************\n\n");
		}
		
	}
	free_file_collector(root);
	return kslOK;
ERROR:
	return kslFAIL;
}

int detect_paired_end(struct file_collector* n,int* pair)
{
	int num_R1 = 0;
	int num_R2 = 0;
	int status;
	
	
	if((status = count_R1_R2(n,&num_R1,&num_R2)) != kslOK) KSLIB_XEXCEPTION(kslFAIL,"count_R1_R2 failed\n");
	
	KSL_DPRINTF3(("Counted:\n%d R1\n%d R2 files\n", num_R1,num_R2));
	
	if(num_R1 &&num_R2){
		if(num_R1 == num_R2){
			KSL_DPRINTF3(("Paired end data detected\n"));
			*pair =  2;
		}else{
			fprintf(stderr,"Looks like a combination of single and paired end data....\n");
			return kslFAIL;
		}
	}
	if(num_R1 && !num_R2){
		KSL_DPRINTF3(("Single end data detected\n"));
		*pair =  1;
	}
	return kslOK;
ERROR:
	return kslFAIL;
}

int count_R1_R2(struct file_collector* n,int* R1,int*R2)
{
	int i;
	int status;
	if(n){
		
		if(n->numread1 && n->numread2){
			if(n->numread1  !=n->numread2) KSLIB_XEXCEPTION(kslFAIL,"There is an unequal number of R1 and R2 files for sample %s:\n%d R1\n%d R2\n",n->id, n->numread1,n->numread2);
		}
		
		*R1 +=n->numread1;
		*R2 +=n->numread2;
		return count_R1_R2(n->next, R1,R2);
	}
	return kslOK;
ERROR:
	return status;
}


struct file_collector* insert (struct file_collector* n, char* id,char* name, int read)
{
	int i;
	int status;
	if(!n){
		MMALLOC(n, sizeof(struct file_collector));
		n->id = NULL;
		
		n->read1 = NULL;
		n->read2 = NULL;
		n->numread1 = 0;
		n->numread2 = 0;
		MMALLOC(n->id, sizeof(char)* MAXFILENAME);
		MMALLOC(n->read1, sizeof(char*)* MAXLANES);
		MMALLOC(n->read2, sizeof(char*)* MAXLANES);
		n->id[0] = 0;
		for(i = 0; i < MAXLANES;i++){
			n->read1[i] = NULL;
			n->read2[i] = NULL;
			MMALLOC(n->read1[i], sizeof(char)* MAXFILENAME);
			MMALLOC(n->read2[i], sizeof(char)* MAXFILENAME);
			n->read1[i][0] = 0;
			n->read2[i][0] = 0;
			
		}
		memcpy(n->id , id, strlen(id)+1);
		MFREE(id);
		if(read == 0){
			memcpy(n->read1[n->numread1] , name, strlen(name)+1);
			n->numread1++;
		}
		
		if(read == 1){
			memcpy(n->read2[n->numread2] , name, strlen(name)+1);
			n->numread2++;
		}
		
		
		
		n->next = NULL;
		return n;
	}
	
	if(strcmp(n->id,id )){
		n->next = insert(n->next, id,name,read);
	}else{
		MFREE(id);
		if(read == 0){
			memcpy(n->read1[n->numread1] , name, strlen(name)+1);
			n->numread1++;
			//	MFREE(name);
		}
		
		if(read == 1){
			memcpy(n->read2[n->numread2] , name, strlen(name)+1);
			n->numread2++;
			//	MFREE(name);
		}
	}
	
	return n;
ERROR:
	return NULL;
}
					      
					      
 void run_concatenate (struct file_collector* n,char* indir, char* outdir)
{
	int i;
	int c;
	
	FILE* file = NULL;
	char command[10000];
	char tmp[10000];
	
	if(n){
		//sort is very important !!
		qsort(n->read1, n->numread1, sizeof(char *), cstring_cmp);
		qsort(n->read2, n->numread2, sizeof(char *), cstring_cmp);
		
		
		//fprintf(stderr,"GROUP:%s\n",n->id );
		//fprintf(stderr,"R1\n");
		//for(i = 0;i <n->numread1;i++){
		//	fprintf(stderr,"%s\n",n->read1[i]);
		//}
		command[0] = 0;
		tmp[0] = 0;
		sprintf (tmp, "cat ");
		strcat ( command, tmp);
		for(i = 0;i <n->numread1;i++){
			sprintf (tmp, "%s/%s ",indir,n->read1[i]);
			strcat ( command, tmp);
		}
		sprintf (tmp, " > %s/%s_R1.fastq.gz",outdir,n->id );
		strcat ( command, tmp);
		
		fprintf(stdout,"Running: %s\n", command);
		
		if (!(file = popen(command, "r"))) {
			fprintf(stderr,"Cannot execute cat with command:%s\n",command);
			exit(-1);
		}
		while ((c = fgetc (file)) != EOF){
			putchar (c);
		}
		pclose(file);
		
		
		
		
		//fprintf(stderr,"R2\n");
		//for(i = 0;i <n->numread2;i++){
		//	fprintf(stderr,"%s\n",n->read2[i]);
		//}
		if(n->numread2){
			command[0] = 0;
			tmp[0] = 0;
			sprintf (tmp, "cat ");
			strcat ( command, tmp);
			for(i = 0;i <n->numread2;i++){
				sprintf (tmp, "%s/%s ",indir,n->read2[i]);
				strcat ( command, tmp);
			}
			sprintf (tmp, " > %s/%s_R2.fastq.gz",outdir,n->id );
			strcat ( command, tmp);
			
			fprintf(stdout,"Running: %s\n", command);
			
			if (!(file = popen(command, "r"))) {
				fprintf(stderr,"Cannot execute cat with command:%s\n",command);
				exit(-1);
			}
			while ((c = fgetc (file)) != EOF){
				putchar (c);
			}
			pclose(file);
		}
		run_concatenate(n->next,indir,outdir);
	}
}
					      
					      
 void print_files (struct file_collector* n)
{
	int i;
	
	
	if(n){
		if(n->numread2){
		
			fprintf(stdout,"SAMPLE:\t%s\n",n->id );
			
			for(i = 0;i <n->numread1;i++){
				fprintf(stdout,"Matched R1 and R2 fastq files %d:\n",i);
				fprintf(stdout,"%s\n%s\n\n",n->read1[i],n->read2[i]);
			}
			fprintf(stdout,"\n\n");
		}else{
			fprintf(stdout,"SAMPLE:\t%s\n",n->id );
			
			for(i = 0;i <n->numread1;i++){
				fprintf(stdout,"Fastq file %d:\n",i);
				fprintf(stdout,"%s\n\n",n->read1[i]);
			}
			fprintf(stdout,"\n");
		}
		print_files(n->next);
	}
}
					      
void free_file_collector (struct file_collector* n)
{
	int i;
	if(n){
		free_file_collector(n->next);
		for(i = 0; i < MAXLANES;i++){
			MFREE(n->read1[i]);//, sizeof(char)* MAXFILENAME);
			MFREE(n->read2[i]);//, sizeof(char)* MAXFILENAME);
		}
		MFREE(n->id);//, , sizeof(char)* MAXFILENAME);
		MFREE(n->read1);//, , sizeof(char*)* MAXLANES);
		MFREE(n->read2);//, , sizeof(char*)* MAXLANES);
		MFREE(n);
	}
}
					      
					      
					      
char* get_base_name(char*filename)
{
	char* basename = NULL;
	
	//int len = strlen(filename);
	int status;
	
	
	int Tc;
	int code = -1;
	int i  = 0;
	
	int s = 0;
	int T[256];
	for (i = 0;i < 256;i++){
		T[i] = 0;
	}
	
	
	int len = (int)strlen(filename);
	int m = 6;//GTCC_L
	
	int mb = (1 << (m-1));
	
	for (i= 0;i < 4;i++){
		
		T[(int)'A'] |= (1 << i);
		T[(int)'C'] |= (1 << i);
		T[(int)'G'] |= (1 << i);
		T[(int)'T'] |= (1 << i);
		T[(int)'a'] |= (1 << i);
		T[(int)'c'] |= (1 << i);
		T[(int)'g'] |= (1 << i);
		T[(int)'t'] |= (1 << i);
	}
	T[(int)'_'] |= (1 << 4);
	T[(int)'L'] |= (1 << 5);
	
	for (i = 0;i < len;i++){
		s <<= 1;
		s |= 1;
		if(!filename[i]){
			code=  -1;
			break;
		}
		Tc = T[(int)filename[i]];
		s &= Tc;
		if(s & mb){
			code =i+1;
			break;
			
		}
	}
	
	if(code != -1){
		MMALLOC(basename, sizeof(char)* (len+3) );
		for(i = 0; i < code -2 ;i++){
			basename[i] = filename[i];
		}
		basename[i] = 0;
	}else{
		
		basename = NULL;
	}
	return basename;
ERROR:
	
	return NULL;
}
					      
				
int cstring_cmp(const void *a, const void *b)
{
	const char **ia = (const char **)a;
	const char **ib = (const char **)b;
	return strcmp(*ia, *ib);
}



