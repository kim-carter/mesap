#include "htio1/Kmer.h"

using namespace std;

namespace htio
{

void encode_nt(const std::string& seq, EncodedSeq& encoded_seq)
{
    const size_t len = seq.length();
    encoded_seq.resize(len);

    EncodedType check = 0;

    for (size_t i = 0; i < len; i++)
    {
        EncodedType curr = encode_nt(seq[i]);
        check |= curr;
        encoded_seq[i] = curr;
    }

    if (check < 0)
        throw runtime_error("sequence to encode contains invalid character: \"" + seq + "\"");
}

void encode_aa(const std::string& seq, EncodedSeq& encoded_seq)
{
    const size_t len = seq.length();
    encoded_seq.resize(len);

    EncodedType check = 0;

    for (size_t i = 0; i < len; i++)
    {
        EncodedType curr = encode_aa(seq[i]);
        check |= curr;
        encoded_seq[i] = curr;
    }

    if (check < 0)
        throw runtime_error("sequence to encode contains invalid character: \"" + seq + "\"");
}

void decode_nt(const EncodedSeq& encoded_seq, std::string& seq)
{
    const size_t len = encoded_seq.size();
    seq.resize(len);

    char check = 0;

    for (size_t i = 0; i < len; i++)
    {
        char curr = decode_nt(encoded_seq[i]);
        seq[i] = curr;
        check |= curr;
    }

    if (check < 0)
        throw runtime_error("sequence to decode contains invalid content");
}

void decode_aa(const EncodedSeq& encoded_seq, std::string& seq)
{
    const size_t len = encoded_seq.size();
    seq.resize(len);

    char check = 0;

    for (size_t i = 0; i < len; i++)
    {
        char curr = decode_aa(encoded_seq[i]);
        seq[i] = curr;
        check |= curr;
    }

    if (check < 0)
        throw runtime_error("sequence to decode contains invalid content");
}

void revcom(const EncodedSeq& in, EncodedSeq& out)
{
    const size_t len = in.size();
    out.resize(len);
    for (size_t i = 0; i < len; i++)
        out[len - i - 1] = 4 - in[i];
}

bool operator==(const EncodedSeq& a, const EncodedSeq& b)
{
    const size_t len = a.size();
    if (len == b.size())
        return false;

    for (size_t i = 0; i < len; i++)
    {
        if (a[i] != b[i]) return false;
    }

    return true;
}

void gen_kmer_nt(const EncodedSeq& encoded_seq, KmerList& result, size_t kmer_size)
{
    size_t len = encoded_seq.size();
    if (len < kmer_size)
        throw runtime_error("seq len shorter than kmer size");

    result.resize(len - kmer_size + 1);

    // the first kmer
    KmerType kmer = 0;
    KmerType digit_base = 1;

    for (size_t k = 0; k < kmer_size; k++)
    {
        kmer += encoded_seq[k] * digit_base;
        digit_base *= 5;
    }

    result[0] = kmer;
    digit_base /= 5;

    // generate kmers from previous kmer
    for (size_t i = 1; i < len - kmer_size + 1; i++)
    {
        kmer -= encoded_seq[i - 1];
        kmer /= 5;
        kmer += encoded_seq[i + kmer_size - 1] * digit_base;
        result[i] = kmer;
    }
}

KmerType gen_kmer_nt(const std::string& input)
{
    EncodedSeq enc;
    encode_nt(input, enc);

    const size_t size = input.length();
    KmerType kmer = 0;
    KmerType digit_base = 1;

    for (size_t i = 0; i < size; i++)
    {
        kmer += enc[i] * digit_base;
        digit_base *= 5;
    }

    return kmer;
}

void gen_kmer_aa(const EncodedSeq& encoded_seq, KmerList& result, size_t kmer_size)
{
    const size_t len = encoded_seq.size();
    if (len < kmer_size)
        throw runtime_error("seq len shorter than kmer size");

    result.resize(len - kmer_size + 1);

    // the first kmer
    KmerType kmer = 0;
    KmerType digit_base = 1;

    for (size_t i = 0; i < kmer_size; i++)
    {
        kmer += encoded_seq[i] * digit_base;
        digit_base *= 26;
    }

    result[0] = kmer;
    digit_base /= 26;

    // generate kmers from previous kmer
    for (size_t i = 1; i < len - kmer_size + 1; i++)
    {
        kmer -= encoded_seq[i - 1];
        kmer /= 26;
        kmer += encoded_seq[i + kmer_size - 1] * digit_base;
        result[i] = kmer;
    }
}

KmerType gen_kmer_aa(const std::string& input)
{
    EncodedSeq enc;
    encode_aa(input, enc);

    const size_t size = input.length();
    KmerType kmer = 0;
    KmerType digit_base = 1;

    for (size_t i = 0; i < size; i++)
    {
        kmer += enc[i] * digit_base;
        digit_base *= 26;
    }

    return kmer;
}

bool operator==(const KmerList& a, const KmerList& b)
{
    const size_t len = a.size();
    if (len == b.size())
        return false;

    for (size_t i = 0; i < len; i++)
    {
        if (a[i] != b[i]) return false;
    }

    return true;
}

void summ_kmer_pos(const KmerList& kmer_list, KmerPosMap& kmer_pos)
{
    for (PosType i = 0; i < kmer_list.size(); i++)
        kmer_pos.insert(make_pair(kmer_list[i], i));
}

char _table_decode_nt[5] = {'A', 'G', 'N', 'C', 'T'};

std::string decode_kmer_nt(KmerType kmer, size_t kmer_size)
{
    string result;

    for (size_t i = 0; i < kmer_size; i++)
    {
        uint8_t rem = kmer % 5;
        result.push_back(_table_decode_nt[rem]);

        kmer -= rem;
        kmer /= 5;
    }
    return result;
}

std::string decode_kmer_aa(KmerType kmer, size_t kmer_size)
{
    string result;

    for (size_t i = 0; i < kmer_size; i++)
    {
        char rem = kmer % 26;

        char chr = rem + 'A';
        if (chr == 'O') chr = '*';
        result.push_back(chr);

        kmer -= rem;
        kmer /= 26;
    }

    return result;
}

} // namespace htio
