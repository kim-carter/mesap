#include "htio1/PlainFileHandle.h"
#include "htio1/GzipFileHandle.h"

using namespace std;
using namespace htio;

int main(int argc, char** argv)
{
    if (argc != 4)
    {
        cerr << "usage: ./line_pass_through INPUT_FILE OUTPUT_FILE plain|gzip" << endl;
        exit(EXIT_FAILURE);
    }

    FileHandle* IN;
    PlainFileHandle OUT(argv[2], "wb");

    if (string(argv[3]) == "plain")
        IN = new PlainFileHandle(argv[1], "rb");
    else if (string(argv[3]) == "gzip")
        IN = new GzipFileHandle(argv[1], "rb");
    else
    {
        cerr << "plain or gzip?" << endl;
        exit(EXIT_FAILURE);
    }

    size_t n_line = 0;
    string curr_line;
    while (IN->read_line(curr_line))
    {
        n_line++;
        if (n_line % 100000 == 0) cout << n_line << " lines passed" << endl;
        OUT.write_line(curr_line);
    }
    cout << n_line << " lines passed" << endl;
}

