/*
 * File:   FastaParser.h
 * Author: yangxi
 *
 * Created on December 19, 2012, 11:24 AM
 */

#ifndef HTIO_FASTAPARSER_H
#define	HTIO_FASTAPARSER_H

#include "htio1/SeqIO.h"

namespace htio
{

class FastaIO : public SeqIO
{
public:
    /**
     * create sequence IO object by file name
     * @param file file to open
     * @param mode read/write/append
     * @param gzipped read an gzipped file, or have output gzipped
     */
    FastaIO(const std::string& file, IOMode mode, bool gzipped = false);

    /**
     * create sequence IO object from HTIO file handle object
     * @param handle
     */
    FastaIO(FileHandle* handle);

    /**
     * create sequence IO object from C standard file handle
     * @param handle
     * @param auto_close if set to true, the underlying handle will be closed when sequence IO object is destroyed
     */
    FastaIO(FILE* handle, bool auto_close = true);

    /**
     * create sequence IO object from Zlib file handle
     * @param handle
     * @param auto_close if set to true, the underlying handle will be closed when sequence IO object is destroyed
     */
    FastaIO(gzFile handle, bool auto_close = true);
    virtual ~FastaIO();

    /**
     * Seek to a file offset.
     * It must be ensured that the offset is always on the beginning of a FASTA entry.
     * The offset can be different with the wrapped FileHandle's offset.
     * See implementation of next_seq() for detail.
     * @param offset
     * @param whence 0 for absolute, 1 for relative
     */
    virtual void seek(off_t offset, int whence = 0);

    /**
     * get the current file offset
     * The offset can be different with the wrapped FileHandle's offset.
     * See implementation of next_seq() for detail.
     * @return file offset that is on the beginning of a FASTA entry.
     */
    virtual off_t tell() const;

    /**
     * read one sequence
     * @param result
     * @return true if got a seq, false if reached end of file
     */
    virtual bool next_seq(SimpleSeq& result);

    /**
     * Read one sequence with quality. As FASTA file don't have quality, the qualities are all marked in '#'.
     * @param result
     * @return true if got a seq, false if reached end of file
     */
    virtual bool next_seq(FastqSeq& result);

    /**
     * write one sequence
     * @param seq the sequence to be written
     */
    virtual void write_seq(const SimpleSeq& seq);
protected:
    /**
     * The FastaIO guarantee that it won't seek while reading and writing.
     * However, it could know the position of a record after the header line was read.
     * Thus we need these facilities to record the file offset before the header line.
     */
    off_t handle_offset;
    void init_buffer();
};
} // namespace htio

#endif	/* HTIO_FASTAPARSER_H */

