#include "htio1/Error.h"
#include <sstream>

namespace htio
{

InvalidQualityEncode::InvalidQualityEncode(QualityEncode encode) : std::invalid_argument(cast<std::string>(encode))
{
}

InvalidQualityEncode::~InvalidQualityEncode() throw ()
{
}

InvalidHeaderFormat::InvalidHeaderFormat(HeaderFormat format) : std::invalid_argument(cast<std::string>(format))
{
}

InvalidHeaderFormat::~InvalidHeaderFormat() throw ()
{
}

std::string _format_file_message(const std::string& content, size_t offset)
{
    std::ostringstream buffer;
    buffer << "invalid file content at offset " << offset << ": " << content;
    return buffer.str();
}

InvalidFileContent::InvalidFileContent(const std::string& content, size_t offset)
: std::runtime_error(_format_file_message(content, offset))
{
}

InvalidFileContent::~InvalidFileContent() throw ()
{
}

} // namespace htio
